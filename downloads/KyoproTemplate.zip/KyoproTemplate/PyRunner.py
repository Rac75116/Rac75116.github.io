import sys, subprocess, ast, os, shutil

try:
    if os.path.isdir("./.log"):
        shutil.rmtree("./.log")
    os.mkdir("./.log")
    path = sys.argv[1]
    try:
        with open(path, "r") as f:
            ast.parse(f.read())
    except SyntaxError as e:
        subprocess.run(f"python {path}")
        print(f"\033[31mSyntax check failed: {e}\033[0m")
        sys.exit(0)
    print("\033[32mSyntax check succeeded\033[0m")
    for i in range(100):
        proc = subprocess.run(
            [
                "python",
                "./CppPyRunnerSub.py",
                str(i + 1),
                os.path.abspath(path),
                os.path.dirname(path),
            ]
        )
        if proc.returncode <= 1:
            sys.exit(proc.returncode)

except KeyboardInterrupt:
    pass
