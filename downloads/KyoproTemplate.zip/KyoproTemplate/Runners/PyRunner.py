import sys, subprocess, ast, os, shutil

curpath = os.path.dirname(__file__)

try:
    if os.path.isdir(os.path.join(curpath, "./.log")):
        shutil.rmtree(os.path.join(curpath, "./.log"))
    os.mkdir(os.path.join(curpath, "./.log"))
    path = sys.argv[1]
    try:
        with open(path, "r") as f:
            ast.parse(f.read())
    except SyntaxError as e:
        subprocess.run(f"python {path}")
        print(f"\033[31mSyntax check failed: {e}\033[0m")
        sys.exit(0)
    print("\033[32mSyntax check succeeded\033[0m")
    for i in range(100):
        proc = subprocess.run(
            [
                "python",
                os.path.join(curpath, "./CppPyRunnerSub.py"),
                str(i + 1),
                os.path.abspath(path),
                os.path.dirname(path),
            ]
        )
        if proc.returncode <= 1:
            sys.exit(proc.returncode)

except KeyboardInterrupt:
    pass
