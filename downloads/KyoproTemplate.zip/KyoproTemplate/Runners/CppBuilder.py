import subprocess, os, time, sys, hashlib, shutil

# compiler = str("g++")
compiler = str("clang++")
release_option = [
    "-std=gnu++20",
    "-O2",
    "-Wall",
    "-Wextra",
    "-march=native",
    "-I.",
    "-I./lib",
]
debug_option = [
    "-g",
    "-gdwarf-4",
    "-std=gnu++20",
    "-O0",
    "-Wall",
    "-Wextra",
    "-march=native",
    "-I.",
    "-I./lib",
]
precompiled = ["./lib/oldlib/oldlib.hpp", "./lib/template/tinytemplate.hpp"]

curpath = os.path.dirname(__file__)


def get_hashed_path(p):
    return hashlib.sha256(os.path.relpath(p).encode()).hexdigest()


try:
    if not os.path.isdir(os.path.join(curpath, "./bin")):
        os.mkdir(os.path.join(curpath, "./bin"))
    compile_type = sys.argv[1]
    path = sys.argv[2]
    exepath = os.path.join(
        curpath,
        "./bin",
        os.path.splitext(os.path.basename(path))[0]
        + f".{get_hashed_path(path)}.{compile_type}.exe",
    )
    option = [compiler]
    if compile_type == "release":
        option += release_option
    elif compile_type == "debug":
        option += debug_option
    else:
        assert False
    raw_paths_proc = subprocess.run(
        option + ["-MM", path], stdout=subprocess.PIPE, text=True
    )
    if raw_paths_proc.returncode != 0:
        print("\033[31mCompilation failed\033[0m")
        sys.exit(1)
    included_paths = list(
        filter(
            lambda x: not len(x) == 0 and not x.startswith("\\"),
            raw_paths_proc.stdout.strip().split(" ")[1:],
        ),
    )
    buildermtime = os.stat(__file__).st_mtime_ns
    updated = False
    if os.path.isfile(exepath):
        exemtime = os.stat(exepath).st_mtime_ns
        if exemtime <= buildermtime:
            updated = True
        else:
            for p in included_paths:
                if exemtime <= os.stat(p).st_mtime_ns:
                    updated = True
                    break
    else:
        updated = True
    include_option = []
    if "clang++" in compiler:
        for p in included_paths:
            for q in precompiled:
                if not os.path.samefile(p, q):
                    continue
                gchpath = os.path.join(
                    curpath,
                    "./bin/"
                    + os.path.basename(p)
                    + f".{get_hashed_path(p)}.{compile_type}.gch",
                )
                include_option += ["-include-pch", gchpath]
                filemtime = os.stat(p).st_mtime_ns
                if os.path.isfile(gchpath):
                    gchmtime = os.stat(gchpath).st_mtime_ns
                    if buildermtime < gchmtime and filemtime < gchmtime:
                        continue
                st = time.perf_counter()
                gch_proc = subprocess.run(
                    option + ["-x", "c++-header", "-o", gchpath, p]
                )
                ed = time.perf_counter()
                if gch_proc.returncode != 0:
                    print(f"\033[31mCompilation failed: {os.path.basename(p)}\033[0m")
                    sys.exit(1)
                updated = True
                print(
                    f"\033[32mCompilation succeeded: {os.path.basename(p)}  ["
                    + str(max(0, round((ed - st) * 1000) - 10))
                    + "ms]\033[0m"
                )
    if updated:
        st = time.perf_counter()
        cp = subprocess.run(option + include_option + ["-o", exepath, path])
        ed = time.perf_counter()
        if cp.returncode != 0:
            print(f"\033[31mCompilation failed: {os.path.basename(path)}\033[0m")
            sys.exit(1)
        if compile_type == "debug":
            shutil.copy(exepath, os.path.join(curpath, "./bin/debug.exe"))
        else:
            shutil.copy(exepath, os.path.join(curpath, "./bin/release.exe"))
        try:
            subprocess.run(exepath, cwd=os.path.dirname(path), timeout=0)
        except subprocess.TimeoutExpired:
            pass
        print(
            f"\033[32mCompilation succeeded: {os.path.basename(path)}  ["
            + str(max(0, round((ed - st) * 1000) - 10))
            + "ms]\033[0m"
        )
    else:
        if compile_type == "debug":
            shutil.copy(exepath, os.path.join(curpath, "./bin/debug.exe"))
        else:
            shutil.copy(exepath, os.path.join(curpath, "./bin/release.exe"))
        try:
            subprocess.run(exepath, cwd=os.path.dirname(path), timeout=0)
        except subprocess.TimeoutExpired:
            pass
        print("\033[32mCompilation was skipped\033[0m")
except KeyboardInterrupt:
    pass
