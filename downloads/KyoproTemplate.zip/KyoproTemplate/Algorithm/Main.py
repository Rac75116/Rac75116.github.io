import sys, bisect, collections, copy, heapq, itertools, math, string, numpy

# fmt: off
sys.setrecursionlimit(10**6)
sys.set_int_max_str_digits(0)
def Str(): return input()
def Int(): return int(input())
def IntArr(): return list(map(int,input().split()))
def StrSeq(N: int): return [input() for i in range(N)]
def IntSeq(N: int): return [int(input()) for i in range(N)]
def IntArr2(N: int): return [list(map(int,input().split())) for i in range(N)]
def YesNo(cond: bool): print("Yes" if cond else "No")
def RevStr(S: str): return "".join(list(reversed(S)))
# fmt: on

try:
    "------------------------"

except KeyboardInterrupt:
    pass
