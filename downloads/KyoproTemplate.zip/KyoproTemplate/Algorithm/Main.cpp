#if !defined(__clang__) && defined(__GNUC__)
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#endif
#ifdef EVAL
#define ONLINE_JUDGE
#endif

#include "oldlib/oldlib.hpp"
//#include <atcoder/all>

#ifdef ONLINE_JUDGE
#define GSH_USE_COMPILE_TIME_CALCULATION
#define NDEBUG
#else
#define GSH_DIAGNOSTICS_COLOR
// #define NDEBUG
#endif

//#include "gsh/BitTree.hpp"
//#include "gsh/FenwickTree.hpp"
//#include "gsh/Geometry.hpp"
//#include "gsh/Heap.hpp"
//#include "gsh/Int128.hpp"
//#include "gsh/Prime.hpp"
//#include "gsh/UnionFind.hpp"
//#include "gsh/Timer.hpp"
//#include "gsh/Random.hpp"
#include "template/template.hpp"

using namespace std;
using namespace gsh;
using namespace gsh::itype;
using namespace gsh::ftype;
using namespace gsh::ctype;
using namespace kyopro;
using namespace atcoder;
void Main() {
    DECLARE_INPUT_STREAM(rd);
    DECLARE_OUTPUT_STREAM(wt);
    /*--------------------------------------------------------------*/
}
