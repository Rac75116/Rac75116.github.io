#include "template/tinytemplate.hpp"

void Main() {}
