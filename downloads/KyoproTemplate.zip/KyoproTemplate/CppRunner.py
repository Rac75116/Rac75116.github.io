import sys, subprocess, os, time, shutil, hashlib


def get_hashed_path(p):
    return hashlib.sha256(os.path.relpath(p).encode()).hexdigest()


try:
    if os.path.isdir("./.log"):
        shutil.rmtree("./.log")
    os.mkdir("./.log")
    path = sys.argv[1]
    exepath = (
        "./bin/"
        + os.path.splitext(os.path.basename(path))[0]
        + f".{get_hashed_path(path)}.release.exe"
    )
    proc = subprocess.run(["python", "-u", "./CppBuilder.py", "release", path])
    if proc.returncode != 0:
        sys.exit(1)
    for i in range(100):
        proc = subprocess.run(
            [
                "python",
                "./CppPyRunnerSub.py",
                str(i + 1),
                os.path.abspath(exepath),
                os.path.dirname(path),
            ]
        )
        if proc.returncode <= 1:
            sys.exit(proc.returncode)

except KeyboardInterrupt:
    pass
