#pragma once
#pragma GCC diagnostic ignored "-Wsign-compare"

#ifndef _GLIBCXX_NO_ASSERT
#include <cassert>
#endif
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cinttypes>
#include <cstdint>
#include <algorithm>
#include <bitset>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>
#include <filesystem>
#include <array>
#include <chrono>
#include <initializer_list>
#include <random>
#include <regex>
#include <tuple>
#include <typeindex>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <charconv>
#include <bit>
#include <compare>
#include <concepts>
#include <ranges>
#include <span>
#include <source_location>

#if true || defined(INCLUDE_UTILITY) || defined(INCLUDE_ALL)
class fprec {
    int d;
public:
    fprec(int d_) : d(d_) {}
    template<class T> friend auto& operator<<(T& os, fprec fp) {
        os << std::fixed << std::setprecision(fp.d);
        return os;
    }
};

template<class T> void make_unique(T& v) {
    std::sort(v.begin(), v.end());
    v.erase(std::unique(v.begin(), v.end()), v.end());
}
template<class T> constexpr T reversed(const T& x) {
    T res = x;
    std::reverse(std::begin(res), std::end(res));
    return res;
}
template<std::ranges::range T, class U> constexpr int find_loc(const T& x, const U& t) {
    int cnt = 0;
    for (const auto& y : x) {
        if (t == y) return cnt;
        ++cnt;
    }
    return -1;
}
template<std::ranges::range T> constexpr auto unique_element(const T& x) {
    using U = std::decay_t<decltype(std::ranges::cbegin(x))>;
    std::map<U, size_t, decltype([](const U& a, const U& b) { return *a < *b; })> m;
    for (U itr = std::ranges::cbegin(x), sen = std::ranges::cend(x); itr != sen; ++itr) ++m[itr];
    for (const auto& [k, v] : m)
        if (v == 1) return k;
    return std::ranges::cend(x);
}
#endif

#if true || defined(INCLUDE_RLE) || defined(INCLUDE_ALL)
template<class Iterator> constexpr auto RLE(Iterator first, Iterator last) {
    std::vector<std::pair<std::decay_t<decltype(*first)>, size_t>> res;
    if (first == last) return res;
    res.emplace_back(*(first++), 1);
    for (auto itr = first; itr != last; ++itr) {
        if (*itr == res.back().first) ++res.back().second;
        else res.emplace_back(*itr, 1);
    }
    return res;
}
#endif

#if true || defined(INCLUDE_INVNUM) || defined(INCLUDE_ALL)
template<class Iterator> std::vector<size_t> Invnum(Iterator first, Iterator last) {
    size_t i = 0, sz = std::distance(first, last);
    std::vector<size_t> res(sz), bit(sz);
    for (Iterator itr = first; i != sz; ++itr, ++i) {
        for (size_t j = *itr; j; j &= j - 1) res[i] += bit[j - 1];
        for (size_t j = *itr + 1; j <= sz; j += (j & (0 - j))) ++bit[j - 1];
    }
    return res;
}
template<class Iterator> size_t Invnum_sum(Iterator first, Iterator last) {
    size_t i = 0, sz = std::distance(first, last), res = 0;
    std::vector<size_t> bit(sz);
    for (Iterator itr = first; i != sz; ++itr, ++i) {
        for (size_t j = *itr; j; j &= j - 1) res += bit[j - 1];
        for (size_t j = *itr + 1; j <= sz; j += (j & (0 - j))) ++bit[j - 1];
    }
    return res;
}
template<class Iterator> size_t Invnum_sum_eq(Iterator first, Iterator last) {
    size_t i = 0, sz = std::distance(first, last), res = 0;
    std::vector<size_t> bit(sz);
    for (Iterator itr = first; i != sz; ++itr, ++i) {
        for (size_t j = *itr + 1; j <= sz; j += (j & (0 - j))) ++bit[j - 1];
        for (size_t j = *itr + 1; j; j &= j - 1) res += bit[j - 1];
    }
    return res;
}
#endif

#if true || defined(INCLUDE_SLIDEMIN) || defined(INCLUDE_ALL)
template<class T, class Operator = std::less<T>> class SlideMin {
    std::deque<std::pair<T, size_t>> deq;
    size_t cnt1 = 0, cnt2 = 0;
    [[no_unique_address]] Operator op;
public:
    SlideMin() : op(Operator()) {}
    SlideMin(Operator op_) : op(op_) {}
    void push(const T& x) {
        while (!deq.empty() && op(x, deq.back().first)) deq.pop_back();
        deq.emplace_back(x, ++cnt1);
    }
    void pop() {
        if (deq.front().second == (++cnt2)) deq.pop_front();
    }
    const T& get() const { return deq.front().first; }
};
#endif

#if true || defined(INCLUDE_INTERVALSCHEDULING) || defined(INCLUDE_ALL)
template<class T> std::vector<bool> IntervalScheduling(std::vector<std::pair<T, T>> x) {
    std::sort(x.begin(), x.end(), [](const std::pair<T, T>& a, const std::pair<T, T>& b) { return a.second < b.second; });
    std::vector<bool> res(x.size(), false);
    auto cur = std::numeric_limits<T>::lowest();
    for (size_t i = 0, sz = x.size(); i != sz; ++i) {
        const bool f = cur <= x[i].first;
        res[i] = f;
        cur = (f ? x[i].second : cur);
    }
    return res;
}
template<class T> size_t IntervalSchedulingCount(std::vector<std::pair<T, T>> x) {
    std::sort(x.begin(), x.end(), [](const std::pair<T, T>& a, const std::pair<T, T>& b) { return a.second < b.second; });
    size_t res = 0;
    auto cur = std::numeric_limits<T>::lowest();
    for (size_t i = 0, sz = x.size(); i != sz; ++i) {
        const bool f = cur <= x[i].first;
        res += f;
        cur = (f ? x[i].second : cur);
    }
    return res;
}

#endif

#if true || defined(INCLUDE_BOOLEANSET) || defined(INCLUDE_ALL)
class BooleanSet {
    std::vector<unsigned> index1;
    std::vector<unsigned> index2;
    unsigned true_counter;

public:
    BooleanSet() {}
    BooleanSet(unsigned N) : index1(N), index2(N), true_counter(0) {
        for (unsigned i = 0; i < N; ++i) index1[i] = index2[i] = i;
    }
    BooleanSet(unsigned N, std::true_type) : index1(N), index2(N), true_counter(N) {
        for (unsigned i = 0; i < N; ++i) index1[i] = index2[i] = i;
    }
    bool test(unsigned N) { return index1[N] < true_counter; }
    void set(unsigned N) {
        if (!test(N)) {
            index1[N] = true_counter;
            index1[index2[true_counter]] = N;
            std::swap(index2[N], index2[true_counter]);
            ++true_counter;
        }
    }
    void reset(unsigned N) {
        if (test(N)) {
            --true_counter;
            index1[N] = true_counter;
            index1[index2[true_counter]] = N;
            std::swap(index2[N], index2[true_counter]);
        }
    }
    auto enumrate() { return std::ranges::subrange(index2.data(), index2.data() + true_counter); }
};
#endif

#if true || defined(INCLUDE_BIT) || defined(INCLUDE_ALL)
template<class T, class Allocator = std::allocator<T>> class RangeSumQuery {
    std::vector<T, Allocator> bit;
public:
    using reference = T&;
    using const_reference = const T&;
    using size_type = size_t;
    using difference_type = ptrdiff_t;
    using value_type = T;
    using allocator_type = Allocator;
    using pointer = typename std::allocator_traits<Allocator>::pointer;
    using const_pointer = typename std::allocator_traits<Allocator>::const_pointer;
    constexpr RangeSumQuery() noexcept(noexcept(Allocator())) : RangeSumQuery(Allocator()) {}
    constexpr explicit RangeSumQuery(const Allocator& alloc) noexcept : bit(alloc) {}
    constexpr explicit RangeSumQuery(size_type n, const Allocator& alloc = Allocator()) : bit(n, alloc) {}
    constexpr RangeSumQuery(size_type n, const T& value, const Allocator& alloc = Allocator()) : bit(alloc) { assign(n, value); }
    template<class InputIter> constexpr RangeSumQuery(InputIter first, InputIter last, const Allocator& alloc = Allocator()) : bit(alloc) { assign(first, last); }
    constexpr RangeSumQuery(const RangeSumQuery&) = default;
    constexpr RangeSumQuery(RangeSumQuery&&) noexcept = default;
    constexpr RangeSumQuery(const RangeSumQuery& x, const Allocator& alloc) : bit(x.bit, alloc) {}
    constexpr RangeSumQuery(RangeSumQuery&& x, const Allocator& alloc) : bit(std::move(x.bit), alloc) {}
    constexpr RangeSumQuery(std::initializer_list<T> il, const Allocator& alloc = Allocator()) : RangeSumQuery(il.begin(), il.end(), alloc) {}
    constexpr RangeSumQuery& operator=(const RangeSumQuery&) = default;
    constexpr RangeSumQuery& operator=(RangeSumQuery&&) noexcept(std::allocator_traits<Allocator>::propagate_on_container_move_assignment::value || std::allocator_traits<Allocator>::is_always_equal::value) = default;
    constexpr RangeSumQuery& operator=(std::initializer_list<T> il) {
        assign(il);
        return *this;
    }
    constexpr size_type size() const noexcept { return bit.size(); }
    /*
    constexpr void resize(size_type sz) { resize(sz, value_type{}); }
    constexpr void resize(size_type sz, const T &c) {
        size_type n = bit.size();
        bit.resize(sz);
        if (n >= sz) return;
        // TODO:
    }
    */
    [[nodiscard]] constexpr bool empty() const noexcept { return bit.empty(); }
    constexpr value_type operator[](size_type n) const {
        value_type res = bit[n];
        if (!(n & 1)) return res;
        size_type tmp = n & (n + 1);
        for (size_type i = n; i != tmp; i &= i - 1) res -= bit[i - 1];
        return res;
    }
    constexpr value_type at(size_type n) const {
        if (n >= size()) throw std::out_of_range("RangeSumQuery::at / Index is out of range.");
        return operator[](n);
    }
    template<class InputIterator> constexpr void assign(InputIterator first, InputIterator last) {
        bit.assign(first, last);
        size_type n = bit.size();
        for (size_type i = 1; i != n; ++i) {
            const size_type a = i - 1;
            const size_type b = i & -i;
            bit[a + b] += (a + b < n ? bit[a] : value_type{});
        }
    }
    constexpr void assign(size_type n, const T& u) {
        if (n == 0) return;
        bit = std::vector<value_type, Allocator>(n, get_allocator());
        std::vector<value_type, Allocator> mul(std::bit_width(n), get_allocator());
        mul[0] = u;
        for (size_type i = 1, sz = mul.size(); i < sz; ++i) mul[i] = mul[i - 1], mul[i] += mul[i - 1];
        for (size_type i = 1; i <= n; ++i) bit[i - 1] = mul[std::countr_zero(i)];
    }
    constexpr void assign(std::initializer_list<T> il) { assign(il.begin(), il.end()); }
    constexpr void swap(RangeSumQuery& x) noexcept(std::allocator_traits<Allocator>::propagate_on_container_swap::value || std::allocator_traits<Allocator>::is_always_equal::value) { bit.swap(x.bit); };
    constexpr void clear() { bit.clear(); }
    constexpr allocator_type get_allocator() const noexcept { return bit.get_allocator(); }
    constexpr void add(size_type n, const value_type& x) {
        for (size_type i = n + 1, sz = size(); i <= sz; i += (i & -i)) bit[i - 1] += x;
    }
    constexpr void minus(size_type n, const value_type& x) {
        for (size_type i = n + 1, sz = size(); i <= sz; i += (i & -i)) bit[i - 1] -= x;
    }
    constexpr void increme(size_type n) {
        for (size_type i = n + 1, sz = size(); i <= sz; i += (i & (-i))) ++bit[i - 1];
    }
    constexpr void decreme(size_type n) {
        for (size_type i = n + 1, sz = size(); i <= sz; i += (i & (-i))) --bit[i - 1];
    }
    constexpr value_type sum(size_type n) const {
        value_type res = {};
        for (size_type i = n; i != 0; i &= i - 1) res += bit[i - 1];
        return res;
    }
    constexpr value_type sum(size_type l, size_type r) const {
        size_type n = l & ~((std::bit_floor(l ^ r) << 1) - 1);
        value_type res = {};
        for (size_type i = r; i != n; i &= i - 1) res += bit[i - 1];
        for (size_type i = l; i != n; i &= i - 1) res -= bit[i - 1];
        return res;
    }
    constexpr size_type lower_bound(value_type x) const {
        static_assert(std::is_unsigned_v<value_type>, "RangeSumQuery::lower_bound / value_type must be unsigned.");
        size_type res = 0, n = size();
        for (size_type len = std::bit_floor(n); len != 0; len >>= 1) {
            if (res + len <= n && bit[res + len - 1] < x) {
                x -= bit[res + len - 1];
                res += len;
            }
        }
        return res;
    }
    constexpr size_type upper_bound(value_type x) const {
        static_assert(std::is_unsigned_v<value_type>, "RangeSumQuery::upper_bound / value_type must be unsigned.");
        size_type res = 0, n = size();
        for (size_type len = std::bit_floor(n); len != 0; len >>= 1) {
            if (res + len <= n && !(x < bit[res + len - 1])) {
                x -= bit[res + len - 1];
                res += len;
            }
        }
        return res;
    }
};
template<class U, class Alloc> constexpr void swap(RangeSumQuery<U, Alloc>& x, RangeSumQuery<U, Alloc>& y) noexcept(noexcept(x.swap(y))) {
    x.swap(y);
}
template<class InputIterator, class Allocator = std::allocator<typename std::iterator_traits<InputIterator>::value_type>> RangeSumQuery(InputIterator, InputIterator, Allocator = Allocator()) -> RangeSumQuery<typename std::iterator_traits<InputIterator>::value_type, Allocator>;
template<class T, class Allocator = std::allocator<T>> using RSQ = RangeSumQuery<T, Allocator>;
#endif

#if true || defined(INCLUDE_STATICRSQ) || defined(INCLUDE_ALL)
template<class T, class Allocator = std::allocator<T>> class StaticRangeSumQuery : public std::vector<T, Allocator> {
public:
    using std::vector<T, Allocator>::vector;
    constexpr void build() {
        for (size_t i = 0, last = this->size() - 1; i != last; ++i) this->operator[](i + 1) += this->operator[](i);
    }
    constexpr T sum(size_t n) const { return (n == 0 ? T{} : this->operator[](n - 1)); }
    constexpr T sum(size_t l, size_t r) const { return (l == 0 ? (r == 0 ? T{} : this->operator[](r - 1)) : this->operator[](r - 1) - this->operator[](l - 1)); }
};
template<class T, class Allocator = std::allocator<T>> class StaticRangeSumQuery2D : public std::vector<std::vector<T, Allocator>, typename std::allocator_traits<Allocator>::template rebind_alloc<std::vector<T, Allocator>>> {
    using base = std::vector<std::vector<T, Allocator>, typename std::allocator_traits<Allocator>::template rebind_alloc<std::vector<T, Allocator>>>;
public:
    using base::base;
    constexpr void build() {
        for (size_t i = 0, h = this->size(); i != h; ++i) {
            for (size_t j = 0, w = (*this)[i].size() - 1; j != w; ++j) (*this)[i][j + 1] += (*this)[i][j];
        }
        for (size_t i = 0, h = this->size() - 1; i != h; ++i) {
            for (size_t j = 0, w = (*this)[i].size(); j != w; ++j) (*this)[i + 1][j] += (*this)[i][j];
        }
    }
    constexpr T sum(size_t x1, size_t y1, size_t x2, size_t y2) const {
        if (x2 == 0 || y2 == 0) return 0;
        if (x1 == 0) {
            if (y1 == 0) return (*this)[x2 - 1][y2 - 1];
            else return (*this)[x2 - 1][y2 - 1] - (*this)[x2 - 1][y1 - 1];
        } else {
            if (y1 == 0) return (*this)[x2 - 1][y2 - 1] - (*this)[x1 - 1][y2 - 1];
            else return (*this)[x2 - 1][y2 - 1] - (*this)[x1 - 1][y2 - 1] - (*this)[x2 - 1][y1 - 1] + (*this)[x1 - 1][y1 - 1];
        }
    }
};
#endif

#if true || defined(INCLUDE_SEGTREE) || defined(INCLUDE_ALL)
template<class T, class Operator, class Allocator = std::allocator<T>> class SegmentTree {
    size_t sz = 0;
    std::vector<T, Allocator> tree;
    [[no_unique_address]] Operator f;
    const T e;
public:
    using reference = T&;
    using const_reference = const T&;
    using size_type = size_t;
    using difference_type = ptrdiff_t;
    using value_type = T;
    using allocator_type = Allocator;
    using pointer = typename std::allocator_traits<Allocator>::pointer;
    using const_pointer = typename std::allocator_traits<Allocator>::const_pointer;
    using operator_type = Operator;
    constexpr SegmentTree(const T& ex) : tree(Allocator()), f(Operator()), e(ex) {}
    constexpr explicit SegmentTree(const Operator& opr, const T& ex, const Allocator& alloc = Allocator()) : tree(alloc), f(opr), e(ex) {}
    constexpr explicit SegmentTree(const T& ex, const Allocator& alloc) : tree(alloc), f(Operator()), e(ex) {}
    constexpr explicit SegmentTree(size_type n, const Operator& opr, const T& ex, const Allocator& alloc = Allocator()) : sz(n), tree((std::bit_ceil(n) << 1) - 1, ex, alloc), f(opr), e(ex) {}
    constexpr explicit SegmentTree(size_type n, const T& ex, const Allocator& alloc = Allocator()) : SegmentTree(n, Operator(), ex, alloc) {}
    constexpr SegmentTree(size_type n, const T& value, const Operator& opr, const T& ex, const Allocator& alloc = Allocator()) : SegmentTree(opr, ex, alloc) { assign(n, value); }
    constexpr SegmentTree(size_type n, const T& value, const T& ex, const Allocator& alloc) : SegmentTree(n, value, Operator(), ex, alloc) {}
    template<class InputIter> constexpr SegmentTree(InputIter first, InputIter last, const Operator& opr, const T& ex, const Allocator& alloc = Allocator()) : tree(alloc), f(opr), e(ex) { assign(first, last); }
    template<class InputIter> constexpr SegmentTree(InputIter first, InputIter last, const T& ex, const Allocator& alloc = Allocator()) : SegmentTree(first, last, Operator(), ex, alloc) {}
    constexpr SegmentTree(const SegmentTree&) = default;
    constexpr SegmentTree(SegmentTree&&) = default;
    constexpr SegmentTree(const SegmentTree& x, const Allocator& alloc) : sz(x.sz), tree(x.tree, alloc), f(x.f), e(x.e) {}
    constexpr SegmentTree(SegmentTree&& y, const Allocator& alloc) : sz(y.sz), tree(std::move(y.tree), alloc), f(y.f), e(std::move(y.e)) {}
    constexpr SegmentTree(std::initializer_list<T> init, const T& ex, const Allocator& alloc = Allocator()) : SegmentTree(init.begin(), init.end(), Operator(), ex, alloc) {}
    constexpr SegmentTree(std::initializer_list<T> init, const Operator& opr, const T& ex, const Allocator& alloc = Allocator()) : SegmentTree(init.begin(), init.end(), opr, ex, alloc) {}
    constexpr SegmentTree& operator=(const SegmentTree&) = default;
    constexpr SegmentTree& operator=(SegmentTree&&) noexcept(std::allocator_traits<Allocator>::propagate_on_container_move_assignment::value || std::allocator_traits<Allocator>::is_always_equal::value) = default;
    constexpr SegmentTree& operator=(std::initializer_list<value_type> il) {
        assign(il);
        return *this;
    }
    constexpr size_type size() const noexcept { return sz; }
    constexpr void resize(size_type n) { resize(n, e); }
    constexpr void resize(size_type n, const T& c) {
        std::vector<value_type> tmp;
        tmp.reserve(sz);
        for (size_t i = 0; i != sz; ++i) tmp.emplace_back(std::move(operator[](i)));
        tmp.resize(n, c);
        assign(tmp.begin(), tmp.end());
    }
    [[nodiscard]] bool empty() const noexcept { return sz == 0; }
    constexpr const_reference operator[](size_type n) const { return tree[n + tree.size() / 2]; }
    constexpr const_reference at(size_type n) const {
        if (n >= sz) throw std::out_of_range("SegmentTree::at / Index is out of range.");
        return tree[n + tree.size() / 2];
    }
    template<class InputIterator> constexpr void assign(InputIterator first, InputIterator last) {
        sz = std::distance(first, last);
        tree.assign((std::bit_ceil(sz) << 1) - 1, e);
        size_t h = tree.size() / 2;
        InputIterator itr = first;
        for (size_t i = 0; i != sz; ++i, ++itr) tree[h + i] = *itr;
        for (size_t i = 0; i != h; ++i) {
            size_t tmp = h - i - 1;
            tree[tmp] = f(tree[(tmp << 1) + 1], tree[(tmp << 1) + 2]);
        }
    }
    constexpr void assign(size_type n, const value_type& u) {
        sz = n;
        tree.assign((std::bit_ceil(sz) << 1) - 1, e);
        size_t h = tree.size() / 2;
        for (size_t i = 0; i != sz; ++i) tree[h + i] = u;
        for (size_t i = 0; i != h; ++i) {
            size_t tmp = h - i - 1;
            tree[tmp] = f(tree[(tmp << 1) + 1], tree[(tmp << 1) + 2]);
        }
    }
    constexpr void assign(std::initializer_list<value_type> il) { assign(il.begin(), il.end()); }
    constexpr void swap(SegmentTree& x) noexcept(std::allocator_traits<Allocator>::propagate_on_container_swap::value || std::allocator_traits<Allocator>::is_always_equal::value) {
        using std::swap;
        swap(sz, x.sz), swap(tree, x.tree), swap(f, x.f);
    };
    constexpr void clear() { sz = 0, tree.clear(); }
    constexpr allocator_type get_allocator() const noexcept { return tree.get_allocator(); }
    constexpr void set(size_type n, const value_type& x) {
        size_type i = n + (tree.size() >> 1);
        tree[i] = x;
        while (i > 0) {
            i = (i - 1) >> 1;
            tree[i] = f(tree[(i << 1) + 1], tree[(i << 1) + 2]);
        }
    }
    constexpr const_reference get(size_type n) const { return operator[](n); }
    constexpr value_type prod(size_type l, size_type r) {
        value_type resl = e, resr = e;
        size_type h = (tree.size() + 1) >> 1;
        for (l += h, r += h; l < r; l = (l + 1) >> 1, r >>= 1) {
            resl = l & 1 ? f(resl, tree[l - 1]) : resl;
            resr = r & 1 ? f(tree[r - 2], resr) : resr;
        }
        return f(resl, resr);
    }
    constexpr value_type all_prod() const { return (sz ? tree[0] : e); }
    // p(prod[l,r)) == true && (r == N || p(prod[l,r]) == false)となるrを一つ見つける
    // p(prod[l,i))がiに関して単調な時、rはp(prod[l,r)) == trueとなる最大のもの
    template<class F> constexpr size_type max_right(size_type l, F p = F()) {
        value_type x = e;
        size_type h = (tree.size() + 1) >> 1;
        for (size_type curl = l + h, curr = tree.size() + 1; curl < curr; curl >>= 1, curr >>= 1) {
            if (curl & 1) {
                value_type tmp = f(x, tree[(++curl) - 2]);
                if (!p(tmp)) {
                    --curl;
                    while (curl < h) {
                        curl <<= 1;
                        value_type tmp = f(x, tree[curl - 1]);
                        if (p(tmp)) {
                            x = tmp, ++curl;
                        }
                    }
                    return curl - h;
                } else x = tmp;
            }
        }
        return sz;
    }
    // p(prod[l,r)) == true && (l == 0 || p(prod[l - 1, r)) == false)となるlを一つ見つける
    // p(prod[i,r))がiに関して単調な時、lはp(prod[l,r)) == trueとなる最小のもの
    /*
    template<class F> constexpr size_type min_left(size_type r, F p = F()) {
        //TODO
        return 0;
    }
    */
};
template<class U, class Opr, class Alloc> constexpr void swap(SegmentTree<U, Opr, Alloc>& x, SegmentTree<U, Opr, Alloc>& y) noexcept(noexcept(x.swap(y))) {
    x.swap(y);
}
template<class T, class Operator, class E, class Allocator = std::allocator<T>> class SegmentTreeWrapper : public SegmentTree<T, Operator, Allocator> {
    using base = SegmentTree<T, Operator, Allocator>;
    using size_type = base::size_type;
public:
    constexpr SegmentTreeWrapper() : base(E()()) {}
    constexpr explicit SegmentTreeWrapper(const Allocator& alloc) : base(E()(), alloc) {}
    constexpr explicit SegmentTreeWrapper(size_type n, const Allocator& alloc = Allocator()) : base(n, E()(), alloc) {}
    constexpr SegmentTreeWrapper(size_type n, const T& value, const Allocator& alloc = Allocator()) : base(n, value, E()(), alloc) {}
    //template<class InputIter> constexpr SegmentTreeWrapper(InputIter first, InputIter last, const Allocator& alloc = Allocator()) : base(first, last, E()(), alloc) {}
    constexpr SegmentTreeWrapper(const SegmentTreeWrapper&) = default;
    constexpr SegmentTreeWrapper(SegmentTreeWrapper&&) = default;
    constexpr SegmentTreeWrapper(const SegmentTreeWrapper& x, const Allocator& alloc) : base(x, E()(), alloc) {}
    constexpr SegmentTreeWrapper(SegmentTreeWrapper&& y, const Allocator& alloc) : base(std::move(y), E()(), alloc) {}
    constexpr SegmentTreeWrapper(std::initializer_list<T> init, const Allocator& alloc = Allocator()) : base(init, E()(), alloc) {}
};
template<class T, class Allocator = std::allocator<T>> using RangeMaximumQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return std::max(a, b); }), decltype([]() { return std::numeric_limits<T>::lowest(); }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeMinimumQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return std::min(a, b); }), decltype([]() { return std::numeric_limits<T>::max(); }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeUnionQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return a + b; }), decltype([]() { return T{}; }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeOrQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return a | b; }), decltype([]() -> T { return 0; }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeAndQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return a & b; }), decltype([]() -> T { return ~static_cast<T>(0); }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeXorQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return a ^ b; }), decltype([]() -> T { return 0; }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeMulQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return a * b; }), decltype([]() -> T { return 1; }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeCompositeQuery = SegmentTreeWrapper<std::pair<T, T>, decltype([](const std::pair<T, T>& a, const std::pair<T, T>& b) { return std::pair<T, T>{ a.first * b.first, a.second * b.first + b.second }; }), decltype([]() { return std::pair<T, T>{ 1, 0 }; }), typename std::allocator_traits<Allocator>::template rebind_alloc<std::pair<T, T>>>;
template<class T, class Allocator = std::allocator<T>> using RangeGCDQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return std::gcd(a, b); }), decltype([]() -> T { return 0; }), Allocator>;
template<class T, class Allocator = std::allocator<T>> using RangeLCMQuery = SegmentTreeWrapper<T, decltype([](const T& a, const T& b) { return std::lcm(a, b); }), decltype([]() -> T { return 1; }), Allocator>;
#endif

#if true || defined(INCLUDE_GRAPH) || defined(INCLUDE_ALL)
template<class Weight> class GraphBase;
namespace Graph {
template<class Weight> struct Edge {
    friend class GraphBase<Weight>;
    using weight_type = Weight;
    size_t to;
    Weight weight;
    constexpr operator size_t() const noexcept { return to; }
private:
    constexpr Edge(size_t t = 0, Weight w = {}) : to(t), weight(w) {}
};
template<> struct Edge<void> {
    friend class GraphBase<void>;
    using weight_type = size_t;
    size_t to;
    constexpr operator size_t() const noexcept { return to; }
private:
    constexpr Edge(size_t t = 0) : to(t) {}
};

struct dsu {
    std::vector<int> par;
    constexpr dsu(size_t n) : par(n, -1) {}
    constexpr int root(int n) {
        if (par[n] < 0) return n;
        return par[n] = root(par[n]);
    }
    constexpr bool merge(int a, int b) {
        int ar = root(a), br = root(b);
        if (ar == br) return false;
        if (par[ar] < par[br]) {
            par[ar] += par[br];
            par[br] = ar;
        } else {
            par[br] += par[ar];
            par[ar] = br;
        }
        return true;
    }
};

}  // namespace Graph

template<class Weight> class GraphBase {
public:
    using edge_type = Graph::Edge<Weight>;
    using weight_type = typename edge_type::weight_type;
    constexpr static bool is_weighted = !std::is_void_v<Weight>;
private:
    struct node {
        edge_type edge;
        node* next;
        constexpr node(size_t t, node* p) : edge(t), next(p) {}
        constexpr node(size_t t, const weight_type& w, node* p) : edge(t, w), next(p) {}
        constexpr node(const node&) = delete;
    };
    std::vector<node*> vertices;
    std::vector<std::unique_ptr<node[]>> edges;
    size_t edges_last = 0;
protected:
    constexpr void connect(size_t from, size_t to) {
        if (edges_last == 0) [[unlikely]]
            edges.emplace_back(static_cast<node*>(::operator new[]((1ull << edges.size()) * sizeof(node))));
        node* tmp = vertices[from];
        vertices[from] = edges.back().get() + edges_last;
        new (vertices[from]) node(to, tmp);
        edges_last *= (++edges_last != (1ull << (edges.size() - 1)));
    }
    constexpr void connect(size_t from, size_t to, const weight_type& w) {
        if (edges_last == 0) [[unlikely]]
            edges.emplace_back(static_cast<node*>(::operator new[]((1ull << edges.size()) * sizeof(node))));
        node* tmp = vertices[from];
        vertices[from] = edges.back().get() + edges_last;
        new (vertices[from]) node(to, w, tmp);
        edges_last *= (++edges_last != (1ull << (edges.size() - 1)));
    }
public:
    constexpr GraphBase() : vertices() {}
    constexpr GraphBase(size_t n) : vertices(n, nullptr) {}
    constexpr GraphBase(const GraphBase&) = default;
    constexpr GraphBase(GraphBase&&) = default;
protected:
#if __GNUC__ >= 12
    constexpr ~GraphBase() = default;
#else
    ~GraphBase() = default;
#endif
public:
    class AdjacencyList {
        friend class GraphBase;
    protected:
        size_t vertex;
        const GraphBase& graph;
        constexpr AdjacencyList(size_t n, const GraphBase& ref) noexcept : vertex(n), graph(ref) {}
    public:
        class iterator {
            friend class AdjacencyList;
            const node* ptr;
            constexpr iterator(const node* p) noexcept : ptr(p) {}
        public:
            constexpr const edge_type& operator*() const noexcept { return ptr->edge; }
            constexpr const edge_type* operator->() const noexcept { return &(ptr->edge); }
            constexpr iterator& operator++() noexcept {
                ptr = ptr->next;
                return *this;
            }
            constexpr iterator& operator++(int) noexcept {
                iterator copy(*this);
                ptr = ptr->next;
                return copy;
            }
            constexpr bool operator==(iterator r) noexcept { return ptr == r.ptr; }
            constexpr bool operator!=(iterator r) noexcept { return ptr != r.ptr; }
        };
        using const_iterator = iterator;
        constexpr iterator begin() noexcept { return iterator(graph.vertices[vertex]); }
        constexpr const_iterator begin() const noexcept { return const_iterator(graph.vertices[vertex]); }
        constexpr const_iterator cbegin() const noexcept { return const_iterator(graph.vertices[vertex]); }
        constexpr iterator end() noexcept { return iterator(nullptr); }
        constexpr const_iterator end() const noexcept { return const_iterator(nullptr); }
        constexpr const_iterator cend() const noexcept { return const_iterator(nullptr); }
        constexpr operator size_t() const noexcept { return vertex; }
    };
    class iterator : AdjacencyList {
        friend class GraphBase;
    protected:
        using AdjacencyList::vertex, AdjacencyList::graph;
        constexpr iterator(size_t n, const GraphBase& ref) : AdjacencyList(n, ref) {}
    public:
        constexpr const AdjacencyList& operator*() const noexcept { return *this; }
        constexpr const AdjacencyList* operator->() const noexcept { return this; }
        constexpr iterator& operator++() noexcept {
            ++vertex;
            return *this;
        }
        constexpr iterator& operator++(int) noexcept {
            iterator copy(*this);
            ++vertex;
            return copy;
        }
        constexpr bool operator==(const iterator& r) noexcept { return vertex == r.vertex && (&graph) == (&r.graph); }
        constexpr bool operator!=(const iterator& r) noexcept { return vertex != r.vertex || (&graph) != (&r.graph); }
    };
    using const_iterator = iterator;
    constexpr iterator begin() noexcept { return iterator(0, *this); }
    constexpr const_iterator begin() const noexcept { return const_iterator(0, *this); }
    constexpr const_iterator cbegin() const noexcept { return const_iterator(0, *this); }
    constexpr iterator end() noexcept { return iterator(count_vertices(), *this); }
    constexpr const_iterator end() const noexcept { return const_iterator(count_vertices(), *this); }
    constexpr const_iterator cend() const noexcept { return const_iterator(count_vertices(), *this); }
    constexpr inline static weight_type inf = std::numeric_limits<weight_type>::max();
    constexpr size_t count_vertices() const noexcept { return vertices.size(); }
protected:
    constexpr size_t count_edges_impl() const noexcept { return edges.empty() ? 0 : (1ull << (edges.size() - 1)) - 1 + edges_last; }
public:
    constexpr AdjacencyList operator[](size_t n) const {
        if (n >= count_vertices()) throw std::out_of_range("GraphBase::operator[] / Index is out of range");
        return AdjacencyList(n, *this);
    }
};

template<class Weight = void> class DirectedGraph : public GraphBase<Weight> {
    using base = GraphBase<Weight>;
    std::vector<size_t> ideg, odeg;
public:
    using edge_type = typename base::edge_type;
    using weight_type = typename base::weight_type;
    constexpr DirectedGraph() : base() {}
    constexpr DirectedGraph(size_t n) : base(n), ideg(n), odeg(n) {}
    constexpr DirectedGraph(const DirectedGraph&) = default;
    constexpr DirectedGraph(DirectedGraph&&) = default;
    constexpr DirectedGraph& connect(size_t n, size_t m) {
        if (n >= base::count_vertices() || m >= base::count_vertices()) throw std::out_of_range("DirectedGraph::connect / Index is out of range");
        ++odeg[n], ++ideg[m];
        base::connect(n, m);
        return *this;
    }
    constexpr DirectedGraph& connect(size_t n, size_t m, weight_type w) {
        if (n >= base::count_vertices() || m >= base::count_vertices()) throw std::out_of_range("DirectedGraph::connect / Index is out of range");
        ++odeg[n], ++ideg[m];
        base::connect(n, m, w);
        return *this;
    }
    constexpr size_t count_edges() const noexcept { return base::count_edges_impl(); }
    constexpr size_t indegree(size_t n) const {
        if (n >= base::count_vertices()) throw std::out_of_range("DirectedGraph::indegree / Index is out of range");
        return ideg[n];
    }
    constexpr const std::vector<size_t>& indegree() const { return ideg; }
    constexpr size_t outdegree(size_t n) const {
        if (n >= base::count_vertices()) throw std::out_of_range("DirectedGraph::outdegree / Index is out of range");
        return odeg[n];
    }
    constexpr const std::vector<size_t>& outdegree() const { return odeg; }
};

template<class Weight = void> class UndirectedGraph : public GraphBase<Weight> {
    using base = GraphBase<Weight>;
    std::vector<size_t> deg;
public:
    using edge_type = typename base::edge_type;
    using weight_type = typename base::weight_type;
    constexpr UndirectedGraph() : base() {}
    constexpr UndirectedGraph(size_t n) : base(n), deg(n) {}
    constexpr UndirectedGraph(const UndirectedGraph&) = default;
    constexpr UndirectedGraph(UndirectedGraph&&) = default;
    constexpr UndirectedGraph& connect(size_t n, size_t m) {
        if (n >= base::count_vertices() || m >= base::count_vertices()) throw std::out_of_range("UndirectedGraph::connect / Index is out of range");
        ++deg[n], ++deg[m];
        base::connect(n, m);
        base::connect(m, n);
        return *this;
    }
    constexpr UndirectedGraph& connect(size_t n, size_t m, weight_type w) {
        if (n >= base::count_vertices() || m >= base::count_vertices()) throw std::out_of_range("UndirectedGraph::connect / Index is out of range");
        ++deg[n], ++deg[m];
        base::connect(n, m, w);
        base::connect(m, n, w);
        return *this;
    }
    constexpr size_t count_edges() const noexcept { return base::count_edges_impl() >> 1; }
    constexpr size_t degree(size_t n) const {
        if (n >= base::count_vertices()) throw std::out_of_range("UndirectedGraph::degree / Index is out of range");
        return deg[n];
    }
    constexpr const std::vector<size_t>& degree() const { return deg; }
    constexpr auto toDirected() const {
        DirectedGraph<weight_type> res(base::count_vertices());
        for (size_t i = 0, n = base::count_vertices(); i != n; ++i) {
            for (auto [j, cost] : base::operator[](i)) {
                res.connect(i, j, cost);
            }
        }
        return res;
    }
    constexpr operator DirectedGraph<weight_type>() const { return toDirected(); }
};

struct ConnectedComponents {
    std::vector<std::vector<size_t>> vertex;
    std::vector<size_t> aff;
#if __GNUC__ >= 12
    constexpr size_t size() const noexcept { return aff.size(); }
    [[nodiscard]] constexpr bool empty() const noexcept { return aff.empty(); }
    constexpr size_t leader(size_t n) const { return vertex[aff[n]][0]; }
    constexpr size_t is_leader(size_t n) const { return vertex[aff[n]][0] == n; }
    constexpr bool same(size_t a, size_t b) const { return aff[a] == aff[b]; }
    constexpr size_t size(size_t n) const { return vertex[aff[n]].size(); }
    constexpr size_t count_groups() const { return vertex.size(); }
    constexpr const std::vector<size_t>& extract(size_t n) const { return vertex[aff[n]]; }
    constexpr const std::vector<std::vector<size_t>>& groups() const { return vertex; }
    constexpr size_t affiliation(size_t n) const { return aff[n]; }
    constexpr const std::vector<size_t>& affiliation() const { return aff; }
#else
    size_t size() const noexcept { return aff.size(); }
    [[nodiscard]] bool empty() const noexcept { return aff.empty(); }
    size_t leader(size_t n) const { return vertex[aff[n]][0]; }
    size_t is_leader(size_t n) const { return vertex[aff[n]][0] == n; }
    bool same(size_t a, size_t b) const { return aff[a] == aff[b]; }
    size_t size(size_t n) const { return vertex[aff[n]].size(); }
    size_t count_groups() const { return vertex.size(); }
    const std::vector<size_t>& extract(size_t n) const { return vertex[aff[n]]; }
    const std::vector<std::vector<size_t>>& groups() const { return vertex; }
    size_t affiliation(size_t n) const { return aff[n]; }
    const std::vector<size_t>& affiliation() const { return aff; }
#endif
    template<class DG> constexpr DG to_directedgraph(const DG& g) const {
        if (aff.size() != g.count_vertices()) throw std::runtime_error("ConnectedComponents::to_directedgraph / The number of vertices does not match.");
        size_t N = aff.size();
        DG res(N);
        for (size_t i = 0; i != N; ++i) {
            if constexpr (DG::is_weighted) {
                for (auto [j, w] : g[i]) {
                    if (aff[i] == aff[j]) res.connect(i, j, w);
                }
            } else {
                for (size_t j : g[i]) {
                    if (aff[i] == aff[j]) res.connect(i, j);
                }
            }
        }
        return res;
    }
    template<class UG> constexpr UG to_undirectedgraph(const UG& g) const {
        if (aff.size() != g.count_vertices()) throw std::runtime_error("ConnectedComponents::to_undirectedgraph / The number of vertices does not match.");
        size_t N = aff.size();
        UG res(N);
        for (size_t i = 0; i != N; ++i) {
            if constexpr (UG::is_weighted) {
                for (auto [j, w] : g[i]) {
                    if (i < j && aff[i] == aff[j]) res.connect(i, j, w);
                }
            } else {
                for (size_t j : g[i]) {
                    if (i < j && aff[i] == aff[j]) res.connect(i, j);
                }
            }
        }
        return res;
    }
};

template<class UG> constexpr size_t CountConnectedComponents(const UG& g) {
    size_t N = g.count_vertices();
    Graph::dsu uf(N);
    size_t res = N;
    for (size_t i = 0; i < N; ++i) {
        for (size_t j : g[i])
            if (uf.merge(i, j)) --res;
    }
    return res;
}
template<class UG> constexpr bool isConnectedGraph(const UG& g) {
    return CountConnectedComponents(g) == 1;
}
template<class UG> constexpr bool isPathGraph(const UG& g) {
    if (g.count_vertices() - 1 != g.count_edges()) return false;
    for (size_t i = 0, n = g.count_vertices(); i != n; ++i) {
        size_t cnt = 0;
        for ([[maybe_unused]] auto& tmp : g[i]) ++cnt;
        if (cnt > 2) return false;
    }
    return isConnectedGraph(g);
}
template<class UG> constexpr bool isTree(const UG& g) {
    if (g.count_vertices() - 1 != g.count_edges()) return false;
    return isConnectedGraph(g);
}

template<class DG> constexpr std::vector<size_t> TopologicalSort(const DG& g) {
    size_t N = g.count_vertices();
    std::vector<size_t> res;
    res.reserve(N);
    std::vector<size_t> d = g.indegree();
    std::vector<size_t> s;
    for (size_t i = 0; i != N; ++i)
        if (d[i] == 0) s.push_back(i);
    size_t cnt = 0;
    while (!s.empty()) {
        ++cnt;
        size_t n = s.back();
        s.pop_back();
        res.push_back(n);
        for (size_t m : g[n]) {
            if (--d[m] == 0) s.push_back(m);
        }
    }
    if (cnt != N) res.clear();
    return res;
}
template<class DG, class Comp> constexpr std::vector<size_t> TopologicalSort(const DG& g, const Comp& c = Comp()) {
    size_t N = g.count_vertices();
    std::vector<size_t> res;
    res.reserve(N);
    std::vector<size_t> d = g.indegree();
    auto comp = [&c](size_t a, size_t b) {
        return !c(a, b);
    };
    std::priority_queue<size_t, std::vector<size_t>, decltype(comp)> s(comp);
    for (size_t i = 0; i != N; ++i)
        if (d[i] == 0) s.push(i);
    size_t cnt = 0;
    while (!s.empty()) {
        ++cnt;
        size_t n = s.top();
        s.pop();
        res.push_back(n);
        for (size_t m : g[n]) {
            if (--d[m] == 0) s.push(m);
        }
    }
    if (cnt != N) res.clear();
    return res;
}


template<class DG> constexpr std::vector<size_t> LongestPathLength(const DG& g) {
    size_t N = g.count_vertices();
    std::vector<size_t> res(N);
    std::vector<size_t> d = g.indegree();
    std::vector<size_t> s;
    for (size_t i = 0; i != N; ++i)
        if (d[i] == 0) s.push_back(i);
    size_t cnt = 0;
    while (!s.empty()) {
        ++cnt;
        size_t n = s.back();
        s.pop_back();
        for (size_t m : g[n]) {
            res[m] = std::max(res[m], res[n] + 1);
            if (--d[m] == 0) s.push_back(m);
        }
    }
    if (cnt != N) res.clear();
    return res;
}

template<class G> constexpr auto TravelingSalesmanProblemLength(const G& g) {
    const size_t N = g.count_vertices();
    if (N >= 32) throw std::runtime_error("TravelingSalesmanProblemLength / The number of vertices is too large.");
    constexpr auto e = std::numeric_limits<typename G::weight_type>::max();
    std::vector dist(N, std::vector(N, e));
    std::vector<size_t> mask(N);
    for (size_t i = 0; i != N; ++i) {
        for (auto [j, w] : g[i]) dist[i][j] = (dist[i][j] < w ? dist[i][j] : w);
        for (size_t j = 0; j != N; ++j)
            if (dist[i][j] != e) mask[i] |= (1ull << j);
    }
    std::vector dp(1ull << N, std::vector(N, e));
    dp[1][0] = 0;
    for (size_t i = 1; i != (1ull << N); ++i) {
        const size_t u = (~i) & ((1ull << N) - 1);
        for (size_t s = i; s != 0;) {
            const int n = std::countr_zero(s);
            s ^= 1ull << n;
            const auto x = dp[i][n];
            if (dp[i][n] == e) continue;
            for (size_t t = u & mask[n]; t != 0;) {
                const size_t m = std::countr_zero(t);
                const auto a = dp[i | (1ull << m)][m];
                const auto b = x + dist[n][m];
                dp[i | (1ull << m)][m] = (a < b ? a : b);
                t ^= 1ull << m;
            }
        }
    }
    auto res = e;
    for (size_t i = 0; i != N; ++i) {
        const auto d = dp[(1ull << N) - 1][i] + dist[i][0];
        res = (res < d ? res : d);
    }
    return res;
}

namespace Graph {
namespace ShortestPath {
    class BFS {};
    class DPonDAG {};
    class Dijkstra {};
    class BFS01 {};
    class BellmanFord {};
    class DFSonTree {};
    class SPFA {};
    class FloydWarshall {};
}  // namespace ShortestPath
template<class G> struct ShortestPathResult {
    constexpr static size_t e = std::numeric_limits<size_t>::max();
    constexpr static auto inf = std::numeric_limits<typename G::weight_type>::max();
    std::vector<size_t> prev;
    std::vector<typename G::weight_type> dist;
    constexpr ShortestPathResult(size_t n) : prev(n, e), dist(n, inf) {}
    constexpr size_t size() const noexcept { return prev.size(); }
    constexpr auto distance(size_t n) const { return dist[n]; }
    constexpr const std::vector<typename G::weight_type>& distance() const { return dist; }
    constexpr std::vector<size_t> path(size_t n) const {
        if (dist[n] == inf) return std::vector<size_t>{};
        std::vector<size_t> res;
        while (n != e) {
            res.push_back(n);
            n = prev[n];
        }
        std::reverse(res.begin(), res.end());
        return res;
    }
    constexpr auto tree() const {
        DirectedGraph res(prev.size());
        for (size_t i = 0, n = prev.size(); i != n; ++i) {
            if (prev[i] == e) continue;
            res.connect(prev[i], i);
        }
        return res;
    }
    constexpr auto weighted_tree() const {
        DirectedGraph<typename G::weight_type> res(prev.size());
        for (size_t i = 0, n = prev.size(); i != n; ++i) {
            if (prev[i] == e) continue;
            res.connect(prev[i], i, dist[i] - dist[prev[i]]);
        }
        return res;
    }
};
}  // namespace Graph
template<class Algorithm, class G> Graph::ShortestPathResult<G> ShortestPath(const G& g, size_t n) {
    size_t N = g.count_vertices();
    Graph::ShortestPathResult<G> res(N);
    res.dist[n] = 0;
    if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::BFS>) {
        std::vector<bool> seen(N, false);
        std::vector<size_t> q(N);
        size_t push = 0, pop = 0;
        q[push++] = n;
        seen[n] = true;
        while (push != pop) {
            size_t node = q[pop++];
            for (size_t next : g[node]) {
                if (seen[next]) continue;
                res.dist[next] = res.dist[node] + 1;
                res.prev[next] = node;
                q[push++] = next;
                seen[next] = true;
            }
        }
    } else if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::DPonDAG>) {
        std::vector<size_t> indeg(N);
        std::vector<size_t> q(N);
        size_t push = 0, pop = 0;
        q[push++] = n;
        std::vector<bool> seen(N, false);
        seen[n] = true;
        while (push != pop) {
            size_t node = q[pop++];
            for (size_t next : g[node]) {
                ++indeg[next];
                if (seen[next]) continue;
                seen[next] = true;
                q[push++] = next;
            }
        }
        push = 0, pop = 0;
        q[push++] = n;
        while (push != pop) {
            size_t node = q[pop++];
            for (auto [next, cost] : g[node]) {
                if (!indeg[next]) continue;
                if (--indeg[next] == 0) {
                    q[push++] = next;
                    auto d = res.dist[node] + cost;
                    if (d < res.dist[next]) {
                        res.dist[next] = d;
                        res.prev[next] = node;
                    }
                }
            }
        }
    } else if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::BFS01>) {
        std::vector<bool> seen(N, false);
        std::vector<size_t> q(2 * N);
        size_t front = N, back = N;
        q[back++] = n;
        while (front != back) {
            size_t node = q[front++];
            if (seen[node]) continue;
            seen[node] = true;
            for (auto [next, cost] : g[node]) {
                bool c = static_cast<bool>(cost);
                auto d = res.dist[node] + c;
                if (d < res.dist[next]) {
                    res.dist[next] = d;
                    res.prev[next] = node;
                    if (c) q[back++] = next;
                    else q[--front] = next;
                }
            }
        }
    } else if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::Dijkstra>) {
        std::vector<std::pair<typename G::weight_type, size_t>> q;
        q.reserve(N);
        constexpr size_t e = std::numeric_limits<size_t>::max();
        std::vector<size_t> loc(N, e);
        auto prioritize = [&](size_t n) {
            auto tmp = q[loc[n]];
            for (size_t i = loc[n], p; i != 0; i = p) {
                p = (i - 1) >> 1;
                if (q[p].first <= tmp.first) {
                    q[i] = tmp;
                    loc[n] = i;
                    return;
                }
                loc[q[p].second] = i;
                q[i] = q[p];
            }
            q[0] = tmp;
            loc[q[0].second] = 0;
        };
        auto push = [&](size_t n, typename G::weight_type w) {
            loc[n] = q.size();
            q.emplace_back(w, n);
            prioritize(n);
        };
        auto pop = [&]() {
            loc[q[0].second] = e;
            std::swap(q[0], q.back());
            q.pop_back();
            if (q.empty()) return;
            auto tmp = q[0];
            size_t i = 0;
            while (true) {
                size_t l = (i << 1) + 1, r = (i << 1) + 2;
                if (r >= q.size()) {
                    if (r == q.size() && q[l].first < tmp.first) {
                        loc[q[l].second] = i;
                        q[i] = q[l];
                        i = l;
                    }
                    break;
                }
                if (q[l].first <= q[r].first) {
                    if (tmp.first <= q[l].first) break;
                    loc[q[l].second] = i;
                    q[i] = q[l];
                    i = l;
                } else {
                    if (tmp.first <= q[r].first) break;
                    loc[q[r].second] = i;
                    q[i] = q[r];
                    i = r;
                }
            }
            loc[tmp.second] = i;
            q[i] = tmp;
        };
        push(n, 0);
        while (!q.empty()) {
            auto [d, node] = q[0];
            pop();
            for (auto [next, cost] : g[node]) {
                auto tmp = d + cost;
                if (res.dist[next] <= tmp) continue;
                res.dist[next] = tmp;
                res.prev[next] = node;
                if (loc[next] == e) push(next, tmp);
                else {
                    q[loc[next]].first = tmp;
                    prioritize(next);
                }
            }
        }
        /*
        using node_type = std::pair<typename G::weight_type, size_t>;
        std::vector<node_type> c;
        c.reserve(g.count_vertices());
        std::priority_queue<node_type, std::vector<node_type>, std::greater<node_type>> q(std::greater<node_type>{}, std::move(c));
        q.emplace(0, n);
        while (!q.empty()) {
            auto [d, node] = q.top();
            q.pop();
            if (d > res.dist[node]) continue;
            for (auto [next, cost] : g[node]) {
                if (d + cost >= res.dist[next]) continue;
                q.emplace(d + cost, next);
                res.dist[next] = d + cost;
                res.prev[next] = node;
            }
        }
        */
    } else if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::BellmanFord>) {
    } else if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::DFSonTree>) {
        std::vector<std::pair<size_t, size_t>> s;
        s.reserve(N);
        s.emplace_back(n, std::numeric_limits<size_t>::max());
        while (!s.empty()) {
            auto [node, prev] = s.back();
            s.pop_back();
            for (auto [next, cost] : g[node]) {
                if (next == prev) continue;
                res.dist[next] = res.dist[node] + cost;
                res.prev[next] = node;
                s.emplace_back(next, node);
            }
        }
    } else if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::SPFA>) {
    } else {
        static_assert(std::conditional_t<false, Algorithm, bool>{}, "ShortestPath / Template parameter 'Algorithm' is invalid.");
    }
    return res;
}
template<class Algorithm, class G> constexpr std::vector<Graph::ShortestPathResult<G>> ShortestPath(const G& g) {
    size_t N = g.count_vertices();
    if constexpr (std::is_same_v<Algorithm, Graph::ShortestPath::FloydWarshall>) {
        std::vector<Graph::ShortestPathResult<G>> res(N, Graph::ShortestPathResult<G>(N));
        for (size_t i = 0; i != N; ++i) {
            res[i].dist[i] = 0;
            for (auto [j, w] : g[i]) {
                if (w < res[i].dist[j]) {
                    res[i].dist[j] = w;
                    res[i].prev[j] = i;
                }
            }
        }
        for (size_t k = 0; k != N; ++k) {
            for (size_t i = 0; i != N; ++i) {
                for (size_t j = 0; j != N; ++j) {
                    if (res[i].dist[k] != Graph::ShortestPathResult<G>::inf && res[k].dist[j] != Graph::ShortestPathResult<G>::inf && res[i].dist[j] > res[i].dist[k] + res[k].dist[j]) {
                        res[i].dist[j] = res[i].dist[k] + res[k].dist[j];
                        res[i].prev[j] = res[k].prev[j];
                    }
                }
            }
        }
        return res;
    } else {
        std::vector<Graph::ShortestPathResult<G>> res;
        for (size_t i = 0; i != N; ++i) res.emplace_back(ShortestPath<Algorithm>(g, i));
        return res;
    }
}

template<class UG> constexpr auto MinimumSpanningForest(const UG& g) {
    size_t N = g.count_vertices();
    size_t M = g.count_edges();
    struct result_type {
        UG graph;
        typename UG::weight_type cost;
    } res{ UG(N), 0 };
    std::vector<std::pair<typename UG::weight_type, std::pair<size_t, size_t>>> edges;
    edges.reserve(M);
    for (size_t v = 0; v != N; ++v) {
        for (auto [next, cost] : g[v]) {
            edges.emplace_back(cost, std::pair<size_t, size_t>{ v, next });
        }
    }
    std::sort(edges.begin(), edges.end());
    Graph::dsu uf(N);
    for (auto [cost, tmp] : edges) {
        auto [a, b] = tmp;
        if (uf.merge(a, b)) {
            res.graph.connect(a, b, cost);
            res.cost += cost;
        }
    }
    return res;
}
template<class UG> constexpr auto MinimumSpanningForestCost(const UG& g) {
    size_t N = g.count_vertices();
    size_t M = g.count_edges();
    typename UG::weight_type res{};
    std::vector<std::pair<typename UG::weight_type, std::pair<size_t, size_t>>> edges;
    edges.reserve(M);
    for (size_t v = 0; v != N; ++v) {
        for (auto [next, cost] : g[v]) {
            edges.emplace_back(cost, std::pair<size_t, size_t>{ v, next });
        }
    }
    std::sort(edges.begin(), edges.end());
    Graph::dsu uf(N);
    for (auto [cost, tmp] : edges) {
        auto [a, b] = tmp;
        if (uf.merge(a, b)) res += cost;
    }
    return res;
}

template<class UG> constexpr std::vector<bool> BipartiteGraphColoring(const UG& g) {
    std::vector<bool> res(g.count_vertices(), false);
    std::vector<bool> seen(g.count_vertices(), false);
    std::vector<size_t> s;
    s.reserve(g.count_vertices());
    for (size_t v = 0, n = g.count_vertices(); v != n; ++v) {
        s.push_back(v);
        seen[v] = true;
        while (!s.empty()) {
            auto node = s.back();
            s.pop_back();
            for (size_t next : g[node]) {
                if (seen[next]) {
                    if (res[node] == res[next]) return std::vector<bool>{};
                    continue;
                }
                res[next] = !res[node];
                seen[next] = true;
                s.push_back(next);
            }
        }
    }
    return res;
}
template<class UG> constexpr bool isBipartiteGraph(const UG& g) {
    size_t N = g.count_vertices();
    Graph::dsu uf(N * 2);
    for (size_t i = 0; i != N; ++i) {
        for (size_t j : g[i]) {
            uf.merge(i, j + N);
            uf.merge(i + N, j);
        }
    }
    for (size_t i = 0; i != N; ++i) {
        if (uf.root(i) == uf.root(i + N)) return false;
    }
    return true;
}

template<class DG> constexpr ConnectedComponents StronglyConnectedComponentsDecomposition(const DG& g) {
    constexpr size_t e = std::numeric_limits<size_t>::max();
    size_t N = g.count_vertices();
    size_t new_ord = 0, group_num = 0;
    std::vector<size_t> visited, low(N), ord(N, e), ids(N);
    visited.reserve(N);
#ifdef ONLINE_JUDGE
    auto dfs = [&](auto self, size_t v) -> void {
#else
    auto dfs = [&](auto& self, size_t v) -> void {
#endif
        low[v] = ord[v] = new_ord++;
        visited.push_back(v);
        for (size_t to : g[v]) {
            if (ord[to] == e) {
                if (!low[to]) self(self, to);
                low[v] = std::min(low[v], low[to]);
            } else low[v] = std::min(low[v], ord[to]);
        }
        if (low[v] == ord[v]) {
            while (true) {
                size_t u = visited.back();
                visited.pop_back();
                ord[u] = N;
                ids[u] = group_num;
                if (u == v) break;
            }
            ++group_num;
        }
    };
    for (size_t i = 0; i != N; ++i)
        if (ord[i] == e) dfs(dfs, i);
    std::vector<size_t> cnt(group_num);
    for (size_t& x : ids) {
        x = group_num - 1 - x;
        ++cnt[x];
    }
    ConnectedComponents res;
    res.vertex.resize(group_num);
    for (size_t i = 0; i != group_num; ++i) res.vertex[i].resize(cnt[i]);
    for (size_t i = 0; i != N; ++i) res.vertex[ids[i]][--cnt[ids[i]]] = i;
    res.aff = std::move(ids);
    return res;
}

template<class UG = UndirectedGraph<void>> constexpr UG GridtoGraph(const std::vector<std::string>& grid, char c = '#') {
    size_t H = grid.size(), W = grid[0].length();
    UG res(H * W);
    for (size_t i = 0; i != H; ++i) {
        for (size_t j = 0; j != W; ++j) {
            if (grid[i][j] == c) continue;
            if (i != 0 && grid[i - 1][j] != c) res.connect((i - 1) * W + j, i * W + j);
            if (j != 0 && grid[i][j - 1] != c) res.connect(i * W + j, i * W + (j - 1));
        }
    }
    return res;
}
#endif

#if true || defined(INCLUDE_MODINT) || defined(INCLUDE_ALL)
template<class T> class ModintTraits : public T {
    using base_type = T;
public:
    using value_type = std::decay_t<decltype(base_type::mod())>;
    using modint_type = ModintTraits;
    constexpr static bool is_staticmod = !requires { base_type::set_mod(0); };
    constexpr ModintTraits() noexcept : T() {}
    template<class U> constexpr ModintTraits(U x) noexcept { operator=(x); }
    constexpr explicit operator value_type() const noexcept { return val(); }
    constexpr static void set_mod(value_type x) {
        static_assert(!is_staticmod, "ModintTraits::set_mod / Mod must be dynamic.");
        if (x <= 1) throw std::runtime_error("ModintTraits::set_mod / Mod must be at least 2.");
        if (x == mod()) return;
        base_type::set_mod(x);
    }
    constexpr value_type val() const noexcept { return base_type::val(); }
    constexpr static value_type mod() noexcept { return base_type::mod(); }
    template<class U> constexpr modint_type& operator=(U x) noexcept {
        static_assert(std::is_integral_v<U>, "ModintTraits::operator= / Only integer types can be assigned.");
        if constexpr (std::is_unsigned_v<U>) {
            if constexpr (std::is_same_v<U, unsigned long long> || std::is_same_v<U, unsigned long>) base_type::assign(static_cast<std::uint64_t>(x));
            else base_type::assign(static_cast<std::uint32_t>(x));
        } else {
            if (x < 0) {
                if constexpr (std::is_same_v<U, long long> || std::is_same_v<U, long>) base_type::assign(static_cast<std::uint64_t>(-x));
                else base_type::assign(static_cast<std::uint32_t>(-x));
                base_type::neg();
            } else {
                if constexpr (std::is_same_v<U, long long> || std::is_same_v<U, long>) base_type::assign(static_cast<std::uint64_t>(x));
                else base_type::assign(static_cast<std::uint32_t>(x));
            }
        }
        return *this;
    }
    constexpr static modint_type raw(value_type x) noexcept {
        modint_type res;
        res.rawassign(x);
        return res;
    }
    template<class Istream> friend Istream& operator>>(Istream& ist, modint_type& x) {
        value_type n;
        ist >> n;
        x = n;
        return ist;
    }
    template<class Ostream> friend Ostream& operator<<(Ostream& ost, modint_type x) { return ost << x.val(); }
    constexpr modint_type inv() const {
        value_type a = 1, b = 0, x = val(), y = mod();
        if (x == 0) throw std::runtime_error("ModintTraits::inv / Zero division is not possible.");
        while (true) {
            if (x <= 1) {
                if (x == 0) [[unlikely]]
                    break;
                else return modint_type::raw(a);
            }
            b += a * (y / x);
            y %= x;
            if (y <= 1) {
                if (y == 0) [[unlikely]]
                    break;
                else return modint_type::raw(mod() - b);
            }
            a += b * (x / y);
            x %= y;
        }
        throw std::runtime_error("ModintTraits::inv / Cannot calculate inverse element.");
    }
    constexpr modint_type pow(uint64_t e) const noexcept {
        modint_type res = modint_type::raw(1), pow = *this;
        while (e) {
            modint_type tmp = pow * pow;
            if (e & 1) res *= pow;
            pow = tmp;
            e >>= 1;
        }
        return res;
    }
    constexpr modint_type operator+() const noexcept { return *this; }
    constexpr modint_type operator-() const noexcept {
        modint_type res = *this;
        res.neg();
        return res;
    }
    constexpr modint_type& operator++() noexcept {
        base_type::inc();
        return *this;
    }
    constexpr modint_type& operator--() noexcept {
        base_type::dec();
        return *this;
    }
    constexpr modint_type operator++(int) noexcept {
        modint_type copy = *this;
        operator++();
        return copy;
    }
    constexpr modint_type operator--(int) noexcept {
        modint_type copy = *this;
        operator--();
        return copy;
    }
    constexpr modint_type& operator+=(modint_type x) noexcept {
        base_type::add(x);
        return *this;
    }
    constexpr modint_type& operator-=(modint_type x) noexcept {
        base_type::sub(x);
        return *this;
    }
    constexpr modint_type& operator*=(modint_type x) noexcept {
        base_type::mul(x);
        return *this;
    }
    constexpr modint_type& operator/=(modint_type x) {
        operator*=(x.inv());
        return *this;
    }
    friend constexpr modint_type operator+(modint_type l, modint_type r) noexcept { return modint_type(l) += r; }
    friend constexpr modint_type operator-(modint_type l, modint_type r) noexcept { return modint_type(l) -= r; }
    friend constexpr modint_type operator*(modint_type l, modint_type r) noexcept { return modint_type(l) *= r; }
    friend constexpr modint_type operator/(modint_type l, modint_type r) { return modint_type(l) /= r; }
    friend constexpr bool operator==(modint_type l, modint_type r) noexcept { return l.val() == r.val(); }
    friend constexpr bool operator!=(modint_type l, modint_type r) noexcept { return l.val() != r.val(); }
    constexpr int legendre() const noexcept {
        value_type res = pow((mod() - 1) >> 1).val();
        return (res <= 1 ? static_cast<int>(res) : -1);
    }
    constexpr int jacobi() const noexcept {
        value_type a = val(), n = mod();
        if (a == 1) return 1;
        if (std::gcd(a, n) != 1) return 0;
        int res = 1;
        while (a != 0) {
            while (!(a & 1) && a != 0) {
                a >>= 1;
                if ((n & 0b111) == 3 || (n & 0b111) == 5) res = -res;
            }
            if ((a & 0b11) == 3 || (n & 0b11) == 3) res = -res;
            std::swap(a, n);
            a %= n;
        }
        if (n != 1) return 0;
        return res;
    }
    constexpr modint_type sqrt() const noexcept {
        const value_type vl = val(), md = mod();
        if (vl <= 1) return *this;
        auto get_min = [](modint_type x) {
            return x.val() > (mod() >> 1) ? -x : x;
        };
        if ((md & 0b11) == 3) return get_min(pow((md + 1) >> 2));
        else if ((md & 0b111) == 5) {
            modint_type res = pow((md + 3) >> 3);
            if constexpr (is_staticmod) {
                constexpr modint_type p = modint_type::raw(2).pow((md - 1) >> 2);
                res *= p;
            } else if (res * res != *this) res *= modint_type::raw(2).pow((md - 1) >> 2);
            return get_min(res);
        } else {
            value_type Q = md - 1;
            uint32_t S = 0;
            while ((Q & 1) == 0) Q >>= 1, ++S;
            if (std::countr_zero(md - 1) < 6) {
                modint_type z = modint_type::raw(1);
                while (z.legendre() != -1) ++z;
                modint_type t = pow(Q), R = pow((Q + 1) / 2);
                if (t.val() == 1) return R;
                uint32_t M = S;
                modint_type c = z.pow(Q);
                do {
                    modint_type U = t * t;
                    uint32_t i = 1;
                    while (U.val() != 1) U = U * U, ++i;
                    modint_type b = c;
                    for (uint32_t j = 0; j < (M - i - 1); ++j) b *= b;
                    M = i, c = b * b, t *= c, R *= b;
                } while (t.val() != 1);
                return get_min(R);
            } else {
                modint_type a = 1;
                while ((a * a - *this).legendre() != -1) ++a;
                modint_type res1 = modint_type::raw(1), res2, pow1 = a, pow2 = modint_type::raw(1), w = a * a - *this;
                value_type e = (md + 1) / 2;
                while (true) {
                    if (e & 1) {
                        modint_type tmp = res1;
                        res1 = res1 * pow1 + res2 * pow2 * w;
                        res2 = tmp * pow2 + res2 * pow1;
                    }
                    e >>= 1;
                    if (e == 0) return get_min(res1);
                    modint_type tmp = pow1;
                    pow1 = pow1 * pow1 + pow2 * pow2 * w;
                    pow2 *= modint_type::raw(2) * tmp;
                }
            }
        }
    }
};
template<std::uint32_t mod_> class StaticModint32_impl {
    using value_type = std::uint32_t;
    using modint_type = StaticModint32_impl;
    value_type val_ = 0;
protected:
    constexpr StaticModint32_impl() noexcept {}
    constexpr value_type val() const noexcept { return val_; }
    static constexpr value_type mod() noexcept { return mod_; }
    constexpr void assign(std::uint32_t x) noexcept { val_ = x % mod_; }
    constexpr void assign(std::uint64_t x) noexcept { val_ = x % mod_; }
    constexpr void rawassign(value_type x) noexcept { val_ = x; }
    constexpr void neg() noexcept { val_ = (val_ == 0 ? 0 : mod_ - val_); }
    constexpr void inc() noexcept { val_ = (val_ == mod_ - 1 ? 0 : val_ + 1); }
    constexpr void dec() noexcept { val_ = (val_ == 0 ? mod_ - 1 : val_ - 1); }
    constexpr void add(modint_type x) noexcept {
        if (mod_ - val_ > x.val_) val_ += x.val_;
        else val_ = x.val_ - (mod_ - val_);
    }
    constexpr void sub(modint_type x) noexcept {
        if (val_ >= x.val_) val_ -= x.val_;
        else val_ = mod_ - (x.val_ - val_);
    }
    constexpr void mul(modint_type x) noexcept { val_ = static_cast<std::uint64_t>(val_) * x.val_ % mod_; }
};
template<std::uint32_t mod_ = 998244353> using StaticModint32 = ModintTraits<StaticModint32_impl<mod_>>;
template<std::uint64_t mod_> class StaticModint64_impl {
    using value_type = std::uint64_t;
    using modint_type = StaticModint64_impl;
    value_type val_ = 0;
protected:
    constexpr StaticModint64_impl() noexcept {}
    constexpr value_type val() const noexcept { return val_; }
    static constexpr value_type mod() noexcept { return mod_; }
    constexpr void assign(std::uint32_t x) noexcept {
        if constexpr (mod_ < (1ull << 32)) val_ = x % mod_;
        else val_ = x;
    }
    constexpr void assign(std::uint64_t x) noexcept { val_ = x % mod_; }
    constexpr void rawassign(value_type x) noexcept { val_ = x; }
    constexpr void neg() noexcept { val_ = (val_ == 0 ? 0 : mod_ - val_); }
    constexpr void inc() noexcept { val_ = (val_ == mod_ - 1 ? 0 : val_ + 1); }
    constexpr void dec() noexcept { val_ = (val_ == 0 ? mod_ - 1 : val_ - 1); }
    constexpr void add(modint_type x) noexcept {
        if (mod_ - val_ > x.val_) val_ += x.val_;
        else val_ = x.val_ - (mod_ - val_);
    }
    constexpr void sub(modint_type x) noexcept {
        if (val_ >= x.val_) val_ -= x.val_;
        else val_ = mod_ - (x.val_ - val_);
    }
    constexpr void mul(modint_type x) noexcept { val_ = static_cast<__uint128_t>(val_) * x.val_ % mod_; }
};
template<std::uint64_t mod_ = 998244353> using StaticModint64 = ModintTraits<StaticModint64_impl<mod_>>;
template<std::uint64_t mod_ = 998244353> using StaticModint = std::conditional_t<(mod_ < (1ull << 32)), StaticModint32<mod_>, StaticModint64<mod_>>;
template<int id> class DynamicModint32_impl {
    using value_type = std::uint32_t;
    using modint_type = DynamicModint32_impl;
    static inline value_type mod_ = 0;
    static inline std::uint64_t mod64_ = 0;
    static inline __uint128_t L_ = 0;
    value_type val_ = 0;
    value_type reduce(std::uint32_t c) const noexcept {
        std::uint32_t q = (c * L_) >> 96;
        return c - q * mod_;
    }
    value_type reduce(std::uint64_t c) const noexcept {
        std::uint64_t q = (c * L_) >> 96;
        return c - q * mod64_;
    }
protected:
    DynamicModint32_impl() noexcept {}
    static void set_mod(value_type newmod) noexcept {
        mod_ = newmod, mod64_ = newmod;
        L_ = ((__uint128_t(1) << 96) - 1) / mod_ + 1;
    }
    value_type val() const noexcept { return val_; }
    static value_type mod() noexcept { return mod_; }
    void assign(std::uint32_t x) noexcept { val_ = reduce(x); }
    void assign(std::uint64_t x) noexcept { val_ = reduce(x); }
    void rawassign(value_type x) noexcept { val_ = x; }
    void neg() noexcept { val_ = (val_ == 0 ? 0 : mod_ - val_); }
    void inc() noexcept { val_ = (val_ == mod_ - 1 ? 0 : val_ + 1); }
    void dec() noexcept { val_ = (val_ == 0 ? mod_ - 1 : val_ - 1); }
    void add(modint_type x) noexcept {
        if (mod_ - val_ > x.val_) val_ += x.val_;
        else val_ = x.val_ - (mod_ - val_);
    }
    void sub(modint_type x) noexcept {
        if (val_ >= x.val_) val_ -= x.val_;
        else val_ = mod_ - (x.val_ - val_);
    }
    void mul(modint_type x) noexcept { val_ = reduce(static_cast<std::uint64_t>(val_) * x.val_); }
};
template<int id = 0> using DynamicModint32 = ModintTraits<DynamicModint32_impl<id>>;
template<int id> class DynamicModint64_impl {
    using value_type = std::uint64_t;
    using modint_type = DynamicModint64_impl;
    static inline value_type mod_ = 0;
    static inline __uint128_t M_ = 0;
    value_type val_ = 0;
protected:
    DynamicModint64_impl() noexcept {}
    static void set_mod(value_type newmod) noexcept {
        mod_ = newmod;
        M_ = std::numeric_limits<__uint128_t>::max() / mod_ + std::has_single_bit(mod_);
    }
    value_type val() const noexcept { return val_; }
    static value_type mod() noexcept { return mod_; }
    void assign(std::uint64_t x) noexcept { val_ = x % mod_; }
    void rawassign(value_type x) noexcept { val_ = x; }
    void neg() noexcept { val_ = (val_ == 0 ? 0 : mod_ - val_); }
    void inc() noexcept { val_ = (val_ == mod_ - 1 ? 0 : val_ + 1); }
    void dec() noexcept { val_ = (val_ == 0 ? mod_ - 1 : val_ - 1); }
    void add(modint_type x) noexcept {
        if (mod_ - val_ > x.val_) val_ += x.val_;
        else val_ = x.val_ - (mod_ - val_);
    }
    void sub(modint_type x) noexcept {
        if (val_ >= x.val_) val_ -= x.val_;
        else val_ = mod_ - (x.val_ - val_);
    }
    void mul(modint_type x) noexcept {
        const std::uint64_t a = (((M_ * val_) >> 64) * x.val_) >> 64;
        const std::uint64_t b = val_ * x.val_;
        const std::uint64_t c = a * mod_;
        const std::uint64_t d = b - c;
        const bool e = d < mod_;
        const std::uint64_t f = d - mod_;
        val_ = e ? d : f;
    }
};
template<int id = 0> using DynamicModint64 = ModintTraits<DynamicModint64_impl<id>>;
template<class Modint> class ModManager {
    Modint::value_type prev;
public:
    ModManager() { prev = Modint::mod(); }
    ~ModManager() {
        if (prev != 0) Modint::set_mod(prev);
    }
    void set_mod(Modint::value_type newmod) { Modint::set_mod(newmod); }
};
template<class Modint> class SwitchModint;
template<uint32_t mod> class SwitchModint<StaticModint32<mod>> {
public:
    using modint_type = StaticModint32<mod>;
    using value_type = typename modint_type::value_type;
};
template<uint64_t mod> class SwitchModint<StaticModint64<mod>> {
public:
    using modint_type = StaticModint64<mod>;
    using value_type = typename modint_type::value_type;
};
template<int id> class SwitchModint<DynamicModint32<id>> {
public:
    using modint_type = DynamicModint32<id>;
    using value_type = typename modint_type::value_type;
    SwitchModint(value_type mod) { modint_type::set_mod(mod); }
};
template<int id> class SwitchModint<DynamicModint64<id>> {
public:
    using modint_type = DynamicModint64<id>;
    using value_type = typename modint_type::value_type;
    SwitchModint(value_type mod) { modint_type::set_mod(mod); }
};
#endif

#if true || defined(INCLUDE_NUMERIC) || defined(INCLUDE_ALL)
//https://lpha-z.hatenablog.com/entry/2020/05/24/231500
template<class T> constexpr T BinaryGCD(T x, T y) {
    if (x == 0 || y == 0) [[unlikely]]
        return x | y;
    const int n = std::countr_zero(x);
    const int m = std::countr_zero(y);
    const int l = n < m ? n : m;
    x >>= n;
    y >>= m;
    T s;
    int t;
    while (x != y) {
        s = y < x ? x - y : y - x;
        t = std::countr_zero(s);
        y = y < x ? y : x;
        x = s >> t;
    }
    return x << l;
}
template<bool trial_division = true> bool isPrime32(const std::uint32_t x) {
    if constexpr (trial_division) {
        if (x % 2 == 0 || x % 3 == 0 || x % 5 == 0 || x % 7 == 0 || x % 11 == 0 || x % 13 == 0 || x % 17 == 0 || x % 19 == 0 || x % 23 == 0 || x % 29 == 0 || x % 31 == 0 || x % 37 == 0 || x % 41 == 0 || x % 43 == 0) return x <= 43 && (x == 2 || x == 3 || x == 5 || x == 7 || x == 11 || x == 13 || x == 17 || x == 19 || x == 23 || x == 29 || x == 31 || x == 37 || x == 41 || x == 43);
        if (x < 47 * 47) return (x > 1);
    } else {
        if (x % 2 == 0 || x % 3 == 0 || x % 5 == 0 || x % 7 == 0) return x <= 7 && (x == 2 || x == 3 || x == 5 || x == 7);
        if (x < 11 * 11) return (x > 1);
    }
    //https://www.techneon.com/download/is.prime.32.base.data
    const static std::uint16_t bases[] = { 1216, 1836,  8885,  4564, 10978, 5228, 15613, 13941, 1553, 173,   3615, 3144, 10065, 9259,  233,  2362, 6244,  6431, 10863, 5920, 6408, 6841, 22124, 2290,  45597, 6935,  4835, 7652, 1051, 445,  5807, 842,  1534, 22140, 1282, 1733, 347,   6311,  14081, 11157, 186,  703,  9862,  15490, 1720, 17816, 10433, 49185, 2535, 9158,  2143,  2840,  664,  29074, 24924, 1035, 41482, 1065,  10189, 8417,  130,  4551,  5159,  48886,
                                           786,  1938,  1013,  2139, 7171,  2143, 16873, 188,   5555, 42007, 1045, 3891, 2853,  23642, 148,  3585, 3027,  280,  3101,  9918, 6452, 2716, 855,   990,   1925,  13557, 1063, 6916, 4965, 4380, 587,  3214, 1808, 1036,  6356, 8191, 6783,  14424, 6929,  1002,  840,  422,  44215, 7753,  5799, 3415,  231,   2013,  8895, 2081,  883,   3855,  5577, 876,   3574,  1925, 1192,  865,   7376,  12254, 5952, 2516,  20463, 186,
                                           5411, 35353, 50898, 1084, 2127,  4305, 115,   7821,  1265, 16169, 1705, 1857, 24938, 220,   3650, 1057, 482,   1690, 2718,  4309, 7496, 1515, 7972,  3763,  10954, 2817,  3430, 1423, 714,  6734, 328,  2581, 2580, 10047, 2797, 155,  5951,  3817,  54850, 2173,  1318, 246,  1807,  2958,  2697, 337,   4871,  2439,  736,  37112, 1226,  527,   7531, 5418,  7242,  2421, 16135, 7015,  8432,  2605,  5638, 5161,  11515, 14949,
                                           748,  5003,  9048,  4679, 1915,  7652, 9657,  660,   3054, 15469, 2910, 775,  14106, 1749,  136,  2673, 61814, 5633, 1244,  2567, 4989, 1637, 1273,  11423, 7974,  7509,  6061, 531,  6608, 1088, 1627, 160,  6416, 11350, 921,  306,  18117, 1238,  463,   1722,  996,  3866, 6576,  6055,  130,  24080, 7331,  3922,  8632, 2706,  24108, 32374, 4237, 15302, 287,   2296, 1220,  20922, 3350,  2089,  562,  11745, 163,   11951 };
    using mint = DynamicModint32<-1>;
    mint::set_mod(x);
    const std::uint32_t h = x * 0xad625b89;
    std::uint32_t d = x - 1;
    mint cur = bases[h >> 24];
    int s = std::countr_zero(d);
    d >>= s;
    cur = cur.pow(d);
    if (cur.val() == 1) return true;
    while (--s) {
        if (cur.val() == x - 1) return true;
        cur *= cur;
    }
    return cur.val() == x - 1;
}
template<bool trial_division = true, bool hashing = false> bool isPrime64(const std::uint64_t x) {
    if (x < 4294967296) return isPrime32<trial_division>(x);
    if constexpr (trial_division) {
        if (x % 2 == 0 || x % 3 == 0 || x % 5 == 0 || x % 7 == 0 || x % 11 == 0 || x % 13 == 0 || x % 17 == 0 || x % 19 == 0 || x % 23 == 0 || x % 29 == 0 || x % 31 == 0 || x % 37 == 0 || x % 41 == 0 || x % 43 == 0) return false;
    } else {
        if (x % 2 == 0 || x % 3 == 0 || x % 5 == 0 || x % 7 == 0) return false;
    }
    using mint = DynamicModint64<-1>;
    mint::set_mod(x);
    std::uint64_t d = x - 1;
    const int s = std::countr_zero(d);
    d >>= s;
    {
        auto test = [&](std::uint64_t a) -> bool {
            mint cur = mint(a).pow(d);
            if (cur.val() <= 1) return true;
            int i = s;
            while (--i) {
                if (cur.val() == x - 1) return true;
                cur *= cur;
            }
            return cur.val() == x - 1;
        };
        //http://miller-rabin.appspot.com/
        if (x < 585226005592931977ull) {
            if (x < 7999252175582851ull) {
                if (x < 350269456337ull) return test(4230279247111683200ull) && test(14694767155120705706ull) && test(16641139526367750375ull);
                else if (x < 55245642489451ull) return test(2ull) && test(141889084524735ull) && test(1199124725622454117ull) && test(11096072698276303650ull);
                else return test(2ull) && test(4130806001517ull) && test(149795463772692060ull) && test(186635894390467037ull) && test(3967304179347715805ull);
            } else return test(2ull) && test(123635709730000ull) && test(9233062284813009ull) && test(43835965440333360ull) && test(761179012939631437ull) && test(1263739024124850375ull);
        } else return test(2ull) && test(325ull) && test(9375ull) && test(28178ull) && test(450775ull) && test(9780504ull) && test(1795265022ull);
    }
}
uint64_t FindFactor(uint64_t x) {
    if (x == 0) return 0;
    if (x == 1) return 1;
    if (x % 2 == 0) return 2;
    using mint = DynamicModint64<-1>;
    mint::set_mod(x);
    static std::mt19937 engine;
    constexpr size_t repeat = 8192;
retry:
    mint r = mint::raw(engine() % (x - 1) + 1), a, b = mint::raw(engine() % (x - 1) + 1);
    size_t k = repeat;
    while (true) {
        for (size_t i = k + 1; --i;) b = b * b + r;
        a = b;
        for (size_t i = 0; i < k; i += repeat) {
            mint mul = mint::raw(1), prev = b;
            for (size_t j = repeat + 1; --j;) mul *= a - (b = b * b + r);
            uint64_t g = BinaryGCD(mul.val(), x);
            if (g == x) {
                mul = mint::raw(1);
                do {
                    mul *= a - (prev = prev * prev + r);
                    g = BinaryGCD(mul.val(), x);
                } while (g == 1);
                if (g == x) goto retry;
            }
            if (g != 1) return g;
        }
        k *= 2;
    }
}
template<bool sort = true, bool trial_division = true, bool hashing = false> std::vector<uint64_t> EnumrateFactors(uint64_t x) {
    std::vector<uint64_t> res;
    if (x == 0) return res;
    if constexpr (trial_division) {
#define DIV(d)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     \
    while (x % d == 0) x /= d, res.push_back(d);
        { DIV(2) DIV(3) DIV(5) DIV(7) DIV(11) DIV(13) DIV(17) DIV(19) DIV(23) DIV(29) DIV(31) DIV(37) DIV(41) DIV(43) }
#undef DIV
    }
    if (x == 1) return res;
    uint64_t tmp1[64];
    uint64_t tmp2[64];
    uint64_t *begin1 = tmp1, *begin2 = tmp2, *end1 = tmp1, *end2 = tmp2;
    *(end1++) = x;
    while (begin1 != end1) {
        for (uint64_t* i = begin1; i != end1; ++i) {
            uint64_t n = *i;
            if (isPrime64<false, hashing>(n)) res.push_back(n);
            else {
                uint64_t g = FindFactor(n);
                *(end2++) = g;
                *(end2++) = n / g;
            }
        }
        uint64_t* tmp = begin1;
        begin1 = begin2;
        end1 = end2;
        begin2 = tmp;
        end2 = tmp;
    }
    if constexpr (sort) std::sort(res.begin(), res.end());
    return res;
}
template<class Modint> class InvTable : SwitchModint<Modint> {
    using mint = Modint;
    std::vector<mint> table;
public:
    using SwitchModint<Modint>::SwitchModint;
    constexpr void init(size_t mx) {
        table.resize(mx);
        table[1] = mint::raw(1);
        if (mx == 1) return;
        auto mod = mint::mod();
        for (size_t i = 2; i != mx; ++i) table[i] = -table[mod % i] * mint::raw(mod / i);
    }
    constexpr mint operator()(size_t n) const noexcept { return table[n]; }
};
template<class Modint> class COMTable_primemod : SwitchModint<Modint> {
    using mint = Modint;
    std::vector<mint> fac, finv;
public:
    using SwitchModint<Modint>::SwitchModint;
    constexpr void init(size_t mx) {
        fac.resize(mx);
        finv.resize(mx);
        fac[0] = finv[0] = mint::raw(1);
        if (mx > 1) fac[1] = finv[1] = mint::raw(1);
        if (mx > 2) {
            for (size_t i = 2; i != mx; ++i) fac[i] = fac[i - 1] * mint::raw(i);
            finv.back() = fac.back().inv();
            for (size_t i = mx - 1; i != 2; --i) finv[i - 1] = finv[i] * mint::raw(i);
        }
    }
    constexpr mint operator()(size_t n, size_t k) const noexcept {
        if (n < k) return 0;
        else return fac[n] * finv[k] * finv[n - k];
    }
};
#if __GNUC__ >= 12
constexpr
#endif
  std::vector<uint32_t>
  generate_primes(uint32_t size) {
    if (size <= 1000) {
        constexpr uint32_t primes[] = { 2,   3,   5,   7,   11,  13,  17,  19,  23,  29,  31,  37,  41,  43,  47,  53,  59,  61,  67,  71,  73,  79,  83,  89,  97,  101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433,
                                        439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997 };
        return std::vector<uint32_t>(std::begin(primes), std::upper_bound(std::begin(primes), std::end(primes), size));
    }
    const uint32_t flag_size = size / 30 + (size % 30 != 0);
    constexpr uint32_t table1[] = { 0,  1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 19, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 23, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 19, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1,
                                    29, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 19, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 23, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 19, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1, 17, 1, 7, 1, 11, 1, 7, 1, 13, 1, 7, 1, 11, 1, 7, 1 };
    constexpr uint8_t table2[] = { 0, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 8, 0, 0, 0, 16, 0, 32, 0, 0, 0, 64, 0, 0, 0, 0, 0, 128 };
    std::vector<uint8_t> flag(flag_size, 0xffu);
    flag[0] = 0b11111110u;
    std::vector<uint32_t> primes{ 2, 3, 5 };
#if __GNUC__ >= 12
    double primes_size = std::is_constant_evaluated() ? size / 8 : size / std::log(size);
#else
    double primes_size = size / std::log(size);
#endif
    primes.reserve(static_cast<size_t>(1.1 * primes_size));
    std::vector<uint32_t> sieved(static_cast<size_t>(primes_size));
    uint32_t *first = sieved.data(), *last;
    uint32_t k, l, x, y;
    uint8_t temp;
    for (k = 0; k * k < flag_size; ++k) {
        while (flag[k] != 0) {
            x = 30ull * k + table1[flag[k]];
            uint32_t limit = size / x;
            primes.push_back(x);
            last = first;
            bool smaller = true;
            for (l = k; smaller; ++l) {
                for (temp = flag[l]; temp != 0; temp &= (temp - 1)) {
                    y = 30u * l + table1[temp];
                    if (y > limit) {
                        smaller = false;
                        break;
                    }
                    *(last++) = x * y;
                }
            }
            flag[k] &= (flag[k] - 1);
            for (uint32_t* i = first; i < last; ++i) flag[*i / 30] ^= table2[*i % 30];
        }
    }
    for (; k < flag_size; k++) {
        while (flag[k] != 0) {
            x = 30 * k + table1[flag[k]];
            if (x > size) return primes;
            primes.push_back(x);
            flag[k] &= (flag[k] - 1);
        }
    }
    return primes;
}
#endif

#if true || defined(INCLUDE_STRING) || defined(INCLUDE_ALL)
std::string unionchar(char a, char b) {
    return { a, b };
}
bool is_palindrome(const std::string& S) {
    size_t n = S.length();
    for (size_t i = 0; i < (n >> 1); i++)
        if (S[i] != S[n - i - 1]) return false;
    return true;
}
std::vector<std::string> strsplit(const std::string& s, char c = ' ') {
    std::vector<std::string> res;
    const char* prev = s.data();
    bool f = false;
    for (const char* cur = s.data(); *cur != '\0'; ++cur) {
        if (*cur == c) {
            if (f) {
                res.emplace_back(prev, cur);
                f = false;
            }
        } else if (!f) {
            prev = cur;
            f = true;
        }
    }
    if (s.back() != c) {
        res.emplace_back(prev, s.data() + s.length());
    }
    return res;
}
bool in_char(const std::string& S, char c) {
    for (char d : S)
        if (c == d) return true;
    return false;
}
bool in_str(const std::string& S, const std::string& T) {
    if (T.length() > S.length()) return false;
    for (size_t i = 0, n = S.length() - T.length(); i != n; ++i) {
        bool f = true;
        for (size_t j = 0, m = T.length(); j != m; ++j)
            if (S[i + j] != T[j]) {
                f = false;
                break;
            }
        if (f) return true;
    }
    return false;
}
std::string fill_str(const std::string& S, size_t N, char c = '0', bool dir = true) {
    if (S.length() >= N) return S;
    if (dir) return std::string(N - S.length(), c) + S;
    else return S + std::string(N - S.length(), c);
}
size_t hamming_distance(const std::string& S, const std::string& T) {
    if (S.length() != T.length()) throw std::runtime_error("hamming_distance / S.length() and T.length() must be the same.");
    size_t res = 0;
    for (size_t i = 0, n = S.length(); i != n; ++i)
        if (S[i] != T[i]) ++res;
    return res;
}
template<class T = int> constexpr T str_to_int(const std::string& s, int base = 10) {
    static_assert(std::is_integral_v<T>, "str_to_int / Result type must be integral.");
    T res{};
    std::from_chars(s.c_str(), s.c_str() + s.length(), res, base);
    return res;
}
template<class T> constexpr std::string int_to_str(T val, int base = 10) {
    static_assert(std::is_integral_v<T>, "int_to_str / Result type must be integral.");
    char buf[sizeof(T) * 8];
    char* last = std::to_chars(buf, buf + sizeof(T) * 8, val, base).ptr;
    return std::string(buf, last);
}
bool is_capitalized(const std::string& S) {
    if (S.length() == 0) return true;
    if (S[0] < 'A' || S[0] > 'Z') return false;
    for (size_t i = 1, n = S.length(); i < n; ++i) {
        if (S[i] < 'a' || S[i] > 'z') return false;
    }
    return true;
}
std::string strreplace(const std::string& S, const char before, const char after) {
    std::string res = S;
    for (char& c : res) {
        if (c == before) c = after;
    }
    return res;
}
#endif

#if true || defined(INCLUDE_GEOMETRY) || defined(INCLUDE_ALL)
double to_rad(double d) {
    return (d / 180.0) * 3.141592653589793;
}
double to_deg(double r) {
    return (r / 3.141592653589793) * 180.0;
}
double sind(double d) {
    return std::sin(to_rad(d));
}
double cosd(double d) {
    return std::cos(to_rad(d));
}
double tand(double d) {
    return std::tan(to_rad(d));
}
double asind(double x) {
    return to_deg(std::asin(x));
}
double acosd(double x) {
    return to_deg(std::acos(x));
}
double atand(double x) {
    return to_deg(std::atan(x));
}
double atan2d(double y, double x) {
    return to_deg(std::atan2(y, x));
}
long double to_rad(long double d) {
    return (d / 180.0) * 3.141592653589793;
}
long double to_deg(long double r) {
    return (r / 3.141592653589793) * 180.0;
}
long double sind(long double d) {
    return std::sin(to_rad(d));
}
long double cosd(long double d) {
    return std::cos(to_rad(d));
}
long double tand(long double d) {
    return std::tan(to_rad(d));
}
long double asind(long double x) {
    return to_deg(std::asin(x));
}
long double acosd(long double x) {
    return to_deg(std::acos(x));
}
long double atand(long double x) {
    return to_deg(std::atan(x));
}
long double atan2d(long double y, long double x) {
    return to_deg(std::atan2(y, x));
}
float hypot_fl(float x1, float y1, float x2, float y2) {
    return std::hypot(x1 - x2, y1 - y2);
}
double hypot_db(double x1, double y1, double x2, double y2) {
    return std::hypot(x1 - x2, y1 - y2);
}
long double hypot_ld(long double x1, long double y1, long double x2, long double y2) {
    return std::hypot(x1 - x2, y1 - y2);
}
template<class T> struct vector2D {
    T x, y;
    constexpr vector2D() : x(0), y(0) {}
    constexpr vector2D(const T& X, const T& Y) : x(X), y(Y) {}
    constexpr T length() { return static_cast<T>(sqrt(static_cast<double>(x * x + y * y))); }
    constexpr double slope() { return atan2(y, x); }
    constexpr vector2D<T>& rorate(double rad) { return *this = vector2D<T>(x * cos(rad) - y * sin(rad), x * sin(rad) + y * cos(rad)); }
    constexpr vector2D<T>& rorate_deg(double deg) {
        double rad = (deg / 180) * 3.141592653589793;
        return *this = vector2D<T>(x * cos(rad) - y * sin(rad), x * sin(rad) + y * cos(rad));
    }
    constexpr vector2D<T> operator~() {
        T&& len = length();
        return vector2D<T>(x / len, y / len);
    }
    constexpr vector2D<T>& operator=(const vector2D<T>& v) {
        x = v.x, y = v.y;
        return *this;
    }
    constexpr vector2D<T>& operator+=(const vector2D<T>& v) {
        x += v.x, y += v.y;
        return *this;
    }
    constexpr vector2D<T>& operator-=(const vector2D<T>& v) {
        x -= v.x, y -= v.y;
        return *this;
    }
    constexpr vector2D<T>& operator*=(const T& s) {
        x *= s, y *= s;
        return *this;
    }
    constexpr vector2D<T>& operator/=(const T& s) {
        x /= s, y /= s;
        return *this;
    }
    friend constexpr bool operator==(const vector2D& v1, const vector2D& v2) { return v1.x == v2.x && v1.y == v2.y; }
    friend constexpr bool operator!=(const vector2D& v1, const vector2D& v2) { return v1.x != v2.x || v1.y != v2.y; }
    friend constexpr bool operator<(const vector2D& v1, const vector2D& v2) {
        T &&len1 = v1.length(), len2 = v2.length();
        if (len1 == len2) return v1.slope() < v2.slope();
        else return len1 < len2;
    }
    friend constexpr bool operator>(const vector2D& v1, const vector2D& v2) {
        T &&len1 = v1.length(), len2 = v2.length();
        if (len1 == len2) return v1.slope() > v2.slope();
        else return len1 > len2;
    }
    friend constexpr bool operator<=(const vector2D& v1, const vector2D& v2) { return !(v1 > v2); }
    friend constexpr bool operator>=(const vector2D& v1, const vector2D& v2) { return !(v1 < v2); }
    friend constexpr vector2D<T> operator+(const vector2D<T>& v1, const vector2D<T>& v2) { return vector2D<T>(v1.x + v2.x, v1.y + v2.y); }
    friend constexpr vector2D<T> operator-(const vector2D<T>& v1, const vector2D<T>& v2) { return vector2D<T>(v1.x - v2.x, v1.y - v2.y); }
    friend constexpr vector2D<T> operator*(const vector2D<T>& v, const T& s) { return vector2D<T>(v.x * s, v.y * s); }
    friend constexpr vector2D<T> operator*(const T& s, const vector2D<T>& v) { return vector2D<T>(v.x * s, v.y * s); }
    friend constexpr vector2D<T> operator/(const vector2D<T>& v, const T& s) { return vector2D<int>(v.x / s, v.y / s); }
    friend constexpr T operator^(const vector2D<T>& v1, const vector2D<T>& v2) { return v1.x * v2.x + v1.y * v2.y; }
    friend constexpr T operator*(const vector2D<T>& v1, const vector2D<T>& v2) { return v1.x * v2.y - v1.y * v2.x; }
};
#endif

#if true || defined(INCLUDE_GCDLCM) || defined(INCLUDE_ALL)
template<class T> constexpr T extend_gcd(T a, T b, T& x, T& y) {
    T c = 1, d = 0;
    x = 0, y = 1;
    for (T div = a / b; div * b < a; div = a / b) {
        T e = a - b * div, f = c - x * div, g = d - y * div;
        a = b, b = e, c = x, d = y, x = f, y = g;
    }
    return b;
}
#endif
