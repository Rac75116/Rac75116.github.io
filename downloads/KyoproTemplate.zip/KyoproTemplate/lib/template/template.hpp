#pragma once
#include "gsh/InOut.hpp"
#include "gsh/Macro.hpp"
#include "gsh/Vec.hpp"
#include "gsh/Algorithm.hpp"
#include "gsh/Debug.hpp"
#include "gsh/Assert.hpp"
#include <immintrin.h>

namespace kyopro {

constexpr gsh::itype::i32 inf32 = (1 << 30) - 32;
constexpr gsh::itype::i64 inf64 = (1ll << 62) - (1ll << 31) - 1;
using ll = gsh::itype::i64;
using ull = gsh::itype::u64;
using db = gsh::ftype::f64;
using ld = long double;
using vb = gsh::Vec<bool>;
using vi = gsh::Vec<gsh::itype::i32>;
using vu = gsh::Vec<gsh::itype::u32>;
using vll = gsh::Vec<gsh::itype::i64>;
using vull = gsh::Vec<gsh::itype::u64>;
using vvb = gsh::Vec2<bool>;
using vvi = gsh::Vec2<gsh::itype::i32>;
using vvu = gsh::Vec2<gsh::itype::u32>;
using vvll = gsh::Vec2<gsh::itype::i64>;
using vvull = gsh::Vec2<gsh::itype::u64>;
using vvvb = gsh::Vec3<bool>;
using vvvi = gsh::Vec3<gsh::itype::i32>;
using vvvu = gsh::Vec3<gsh::itype::u32>;
using vvvll = gsh::Vec3<gsh::itype::i64>;
using vvvull = gsh::Vec3<gsh::itype::u64>;
using str = gsh::Str;
using vstr = gsh::Vec<gsh::Str>;
using pii = std::pair<gsh::itype::i32, gsh::itype::i32>;
using pll = std::pair<gsh::itype::i64, gsh::itype::i64>;

}  // namespace kyopro

#if defined(HEURISTIC) && !defined(HEURISTIC_TEST) && !defined(ONLINE_JUDGE)
#include <fcntl.h>
namespace kyopro {
gsh::BasicReader rd(open("IO-In.txt", O_RDONLY));
gsh::BasicWriter wt(open("IO-Out.txt", O_WRONLY | O_TRUNC));
}  // namespace kyopro
#else
namespace kyopro {
#if defined(ONLINE_JUDGE)
gsh::MmapReader rd;
#else
gsh::BasicReader rd;
#endif
#if 1 || !defined ONLINE_JUDGE
gsh::BasicWriter wt;
#else
#define NO_WT
#endif
}  // namespace kyopro
#endif

namespace kyopro {

void Yes() {
    wt.writeln("Yes");
}
void No() {
    wt.writeln("No");
}
void YesNo(bool f) {
    wt.writeln(f ? "Yes" : "No");
}

}  // namespace kyopro

void Main();
int main() {
#ifdef NDEBUG
    Main();
#ifndef NO_WT
    kyopro::wt.reload();
#endif
#else
    try {
        Main();
        kyopro::wt.reload();
    } catch (gsh::Exception& e) {
        kyopro::wt.writeln("gsh::Exception was throwed:", e.what());
        kyopro::wt.reload();
        return 1;
    }
#endif
}

namespace atcoder {}

#define rep       REP
#define rrep      RREP
#define in        INPUT
#define tied      TIED
#define lam       LAMBDA
#define out       OUTPUT
#define dbg       DEBUG
#define asrt      ASSERT
#define iter      ITERATE
#define match     MATCH
#define then      THEN
#define inrg      INRANGE
#define all(...)  std::ranges::begin(__VA_ARGS__), std::ranges::end(__VA_ARGS__)
#define rall(...) std::ranges::rbegin(__VA_ARGS__), std::ranges::rend(__VA_ARGS__)
