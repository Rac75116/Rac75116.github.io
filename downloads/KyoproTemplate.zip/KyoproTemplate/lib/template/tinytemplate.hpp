#pragma once
#if !defined(__clang__) && defined(__GNUC__)
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#endif
#ifdef EVAL
#define ONLINE_JUDGE
#endif
#ifdef ONLINE_JUDGE
#define NDEBUG
#endif
#ifndef _GLIBCXX_NO_ASSERT
#include <cassert>
#endif
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cinttypes>
#include <cstdint>
#include <algorithm>
#include <bitset>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>
#include <array>
#include <filesystem>
#include <chrono>
#include <initializer_list>
#include <random>
#include <regex>
#include <tuple>
#include <typeindex>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <charconv>
#include <bit>
#include <compare>
#include <concepts>
#include <ranges>
#include <span>
#include <source_location>
#include <immintrin.h>
using namespace std;

[[maybe_unused]] constexpr int inf32 = (1 << 29) - 1;
[[maybe_unused]] constexpr unsigned infu32 = (1u << 30) - 1;
[[maybe_unused]] constexpr long long inf64 = (1ll << 61) - 1;
[[maybe_unused]] constexpr unsigned long long infu64 = (1ull << 62) - 1;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using vb = vector<bool>;
using vi = vector<int>;
using vu = vector<unsigned>;
using vll = vector<long long>;
using vull = vector<unsigned long long>;
using vvb = vector<vb>;
using vvi = vector<vi>;
using vvu = vector<vu>;
using vvll = vector<vll>;
using vvull = vector<vull>;
using vvvb = vector<vvb>;
using vvvi = vector<vvi>;
using vvvu = vector<vvu>;
using vvvll = vector<vvll>;
using vvvull = vector<vvull>;
using str = string;
using vstr = vector<string>;
using pii = std::pair<int, int>;
using pll = std::pair<ll, ll>;

#define INTERNAL_SELECT3(a, b, c, ...) c
#define INTERNAL_REP1(n)               std::views::iota(std::decay_t<decltype(n)>(), n)
#define INTERNAL_REP2(n, m)            std::views::iota(static_cast<std::common_type_t<std::decay_t<decltype(n)>, std::decay_t<decltype(m)>>>(n), static_cast<std::common_type_t<std::decay_t<decltype(n)>, std::decay_t<decltype(m)>>>(m))
#define rep(varname, ...)              for ([[maybe_unused]] const auto& varname : INTERNAL_SELECT3(__VA_ARGS__, INTERNAL_REP2, INTERNAL_REP1)(__VA_ARGS__))
#define rrep(varname, ...)             for ([[maybe_unused]] const auto& varname : INTERNAL_SELECT3(__VA_ARGS__, INTERNAL_REP2, INTERNAL_REP1)(__VA_ARGS__) | std::views::reverse)
#define all(...)                       std::ranges::begin(__VA_ARGS__), std::ranges::end(__VA_ARGS__)
#define rall(...)                      std::ranges::rbegin(__VA_ARGS__), std::ranges::rend(__VA_ARGS__)

void Main();
int main() {
    cin.tie(0)->sync_with_stdio(0);
    Main();
}
