import time, subprocess, queue, threading, os, sys, psutil, re

prefer_pypy = True

idx = int(sys.argv[1])
path = sys.argv[2]
cwd = sys.argv[3]


def read_output(pipe, q, tp):
    for line in iter(pipe.readline, ""):
        q.put((tp, line))
    pipe.close()


def read_input(q):
    sys.stdout.write(" \033[2m|\033[0m ")
    sys.stdout.flush()
    for line in sys.stdin:
        sys.stdout.write(" \033[2m|\033[0m ")
        sys.stdout.flush()
        q.put(line.strip() + "\n")


max_memory = 0
max_time = 0


def measure(proc: psutil.Popen):
    global max_memory
    global max_time
    try:
        while True:
            cur_memory = proc.memory_info().peak_wset
            cur_time = proc.cpu_times()
            max_memory = max(max_memory, cur_memory // (1024 * 1024))
            max_time = max(max_time, round((cur_time.user + cur_time.system) * 1000))
            time.sleep(0.01)
    except psutil.NoSuchProcess:
        pass


inputs = []
outputs = []
errors = []


def write_log():
    ansi = re.compile(r"\x1B\[\d+(;\d+){0,2}m")

    def remove_ansi(txt):
        return ansi.sub("", txt)

    with open(f"./.log/{str(idx).zfill(4)}.in.txt", "w") as f:
        f.writelines(map(remove_ansi, inputs))
    with open(f"./.log/{str(idx).zfill(4)}.out.txt", "w") as f:
        f.writelines(map(remove_ansi, outputs))
    with open(f"./.log/{str(idx).zfill(4)}.err.txt", "w") as f:
        f.writelines(map(remove_ansi, errors))


cnt = 0
if os.path.splitext(path)[1] == ".py":
    if prefer_pypy:
        pypy = subprocess.run(
            "pypy --version", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        if pypy.returncode == 0:
            cmd = ["pypy", "-u", path]
        else:
            cmd = ["python", "-u", path]
    else:
        cmd = ["python", "-u", path]
else:
    cmd = path
proc = psutil.Popen(
    cmd,
    cwd=cwd,
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
)
try:
    measure_thread = threading.Thread(target=measure, args=(proc,), daemon=True)
    measure_thread.start()
    input_queue = queue.Queue()
    output_queue = queue.Queue()
    input_thread = threading.Thread(target=read_input, args=(input_queue,), daemon=True)
    stdout_thread = threading.Thread(
        target=read_output, args=(proc.stdout, output_queue, "LOG"), daemon=True
    )
    stderr_thread = threading.Thread(
        target=read_output, args=(proc.stderr, output_queue, "ERR"), daemon=True
    )
    input_thread.start()
    stdout_thread.start()
    stderr_thread.start()
    while proc.poll() is None:
        while proc.stdin:
            try:
                time.sleep(0.01)
                input_line = input_queue.get_nowait()
                inputs.append(input_line)
                cnt += 1
                proc.stdin.write(input_line)
                proc.stdin.flush()
            except queue.Empty:
                break
        try:
            tp, line = output_queue.get_nowait()
            if tp == "LOG":
                outputs.append(line)
                sys.stdout.write(
                    "\033[0m\033[2K\033[0E \033[34m|\033[0m "
                    + line.strip()
                    + "\n \033[2m|\033[0m "
                )
                sys.stdout.flush()
            elif tp == "ERR":
                errors.append(line)
                sys.stderr.write(
                    "\033[0m\033[2K\033[0E \033[33m|\033[0m "
                    + line.strip()
                    + "\n \033[2m|\033[0m "
                )
                sys.stderr.flush()
        except queue.Empty:
            pass
    while True:
        try:
            tp, line = output_queue.get_nowait()
            if tp == "LOG":
                outputs.append(line)
                sys.stdout.write(
                    "\033[0m\033[2K\033[0E \033[34m|\033[0m " + line.strip() + "\n"
                )
                sys.stdout.flush()
            elif tp == "ERR":
                errors.append(line)
                sys.stderr.write(
                    "\033[0m\033[2K\033[0E \033[33m|\033[0m " + line.strip() + "\n"
                )
                sys.stderr.flush()
        except queue.Empty:
            break
    if proc.stdin:
        proc.stdin.close()
    proc.wait()
    measure_thread.join()
except KeyboardInterrupt:
    if proc.stdin:
        proc.stdin.close()
    proc.wait()
    write_log()
    sys.stdout.write(
        f"\033[0m\033[2K\033[0E\033[35m#{idx} Keyboard Interrupt  [{max_time}ms | {max_memory}MB]\033[0m\n"
    )
    sys.stdout.flush()
    sys.exit(0)
write_log()
if proc.poll() != 0:
    sys.stdout.write(
        f"\033[0m\033[2K\033[0E\033[31m#{idx} Execusion failed  [{max_time}ms | {max_memory}MB]\033[0m\n"
    )
    sys.stdout.flush()
    sys.exit(1)
sys.stdout.write(
    f"\033[0m\033[2K\033[0E\033[32m#{idx} Execusion succeeded  [{max_time}ms | {max_memory}MB]\033[0m\n"
)
sys.stdout.flush()
sys.exit(0 if cnt == 0 else 2)
